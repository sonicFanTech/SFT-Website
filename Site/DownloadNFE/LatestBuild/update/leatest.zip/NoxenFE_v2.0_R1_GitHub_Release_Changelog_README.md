# NoxenFE: Razer Native — v2.0.1 R1.1 Update Notes

- Added standalone `resources/update/NFEUpdate.exe` updater project.
- Added updater data folders: `Logs`, `RoleBacks`, `cashes`, `Checksums`, and `DownloadedUpdatePackage`.
- Added update package type setting for ZIP / 7z / TAR / WIM while keeping URLs/build channel fixed by build type.
- Added built-in Light, Dark, and System themes under `resources/Themes/built-in/`.
- Added `resources/Themes/custom/` placeholder for later custom theme support.
- Moved NFE settings and SaveData to `resources/SaveData/`.
- Backspace/Back key in file views now goes Up like the Up button.
- Version label bumped to `v2.0.1 R1.1`.

# Noxen File Explorer: Razer Native — v2.0 R1

**Release type:** Major native rebuild / final v2.0 R1 release  
**Build name:** NoxenFE: Razer Native  
**Version:** v2.0  
**Release:** R1  
**Platform:** Windows x64  
**Framework:** C++ / Qt 6 / Native Windows APIs  
**Status:** Final release build

---

## Overview

**Noxen File Explorer: Razer Native v2.0 R1** is a full native C++ rebuild of the original Python/PySide6 Noxen File Explorer.

The original Noxen File Explorer had the basic idea and layout already working, but the Python version could become laggy, buggy, and more crash-prone on newer Windows systems. This release rebuilds the project as a faster, more native Windows file explorer while keeping the original Noxen-style workflow and bringing back many of the older features in a cleaner way.

This release is not just a small update. It is a full rebuild with a new internal structure, native Windows integration, a modular feature-DLL system, MTP phone browsing support, built-in archive/ISO tools through 7-Zip, improved view modes, a better start page, Quick Access tools, preview/details pane, licensing windows, and a special optional one-file EXE build.

---

## Download Options

This release is meant to have two main distribution styles:

### Recommended Build

Use the normal installed or extracted build for the best stability.

This build keeps the EXE, Qt runtime files, custom feature DLLs, resources, 7-Zip files, and licenses as normal files and folders. This is the cleanest layout and the easiest to update or debug.

### One-File EXE Build

A one-file EXE version is also available for users who want a single portable executable.

The one-file build embeds the full runtime payload inside the EXE. Because Windows and Qt cannot reliably load all normal DLLs and Qt platform plugins directly from inside an EXE, the one-file build extracts its private runtime on launch and then starts NoxenFE from that extracted runtime.

Runtime extraction location:

```text
%LOCALAPPDATA%\Noxen File Explorer\OneFileRuntime\
```

From the user's point of view, only one EXE needs to be downloaded and launched.

---

## Project Links

- **GitHub:** https://github.com/sonicFanTech/Noxen-File-explorer
- **Website:** https://sonicfantech.org/Site/DownloadNFE/

---

## Major Changes in v2.0 R1

### Full Native C++ Rebuild

Noxen File Explorer has been rebuilt from the older Python/PySide6 version into a native C++/Qt application.

This rebuild is designed to improve:

- Startup speed
- Folder browsing responsiveness
- Stability
- Native Windows behavior
- File operation reliability
- Long-term maintainability
- Runtime packaging
- Feature expansion through custom DLLs

The new build is no longer treated as a Python script converted into an EXE. It is now a real native desktop application.

---

## Final Release Highlights

### New Native UI Foundation

The main NoxenFE window has been rebuilt in C++/Qt with a Windows desktop layout inspired by the original Noxen File Explorer.

Included UI areas:

- Menu bar
- Toolbar
- Address bar
- Search box
- Sidebar/navigation pane
- Tab system
- Folder view
- This PC view
- Home/Quick Access page
- Preview/details pane
- Context menus
- Settings window
- About window
- License windows

### Tabbed File Browsing

The tab system is now part of the native C++ build.

Added tab features include:

- Multiple folder tabs
- New tab support
- Close tab support
- Duplicate tab support
- Close other tabs
- Remembering open tabs between sessions
- Better startup behavior so the Home page still opens properly
- Tab right-click menu

### Address Bar and Navigation

The address bar supports normal path entry and direct navigation.

Added navigation behavior:

- Enter a folder path directly
- Use `Ctrl + L` to focus and select the address bar
- Back navigation
- Forward navigation
- Up navigation
- Refresh current folder
- Home page navigation
- This PC navigation
- MTP path navigation
- Command running from the address bar for command-style entries

---

## Home / Quick Access Page

A new Home page was added as the main start page.

The Home page includes:

- Common folders
- Quick Access locations
- Pinned folders
- Recent locations
- Recent files
- Drive shortcuts
- Cleaner startup workflow

Quick Access data can now be managed more easily.

Added cleanup actions:

- Remove pinned folder
- Remove all pinned folders
- Clear recent locations
- Clear recent files
- Clear all Quick Access data

These tools make it much easier to reset the Home page without manually editing settings files.

---

## This PC and Drive Support

The new This PC page provides a custom native drive overview.

Drive features include:

- Local drives
- Removable drives
- USB drives
- HDD/SSD detection through Windows drive listing
- Storage usage bars
- Custom drive color settings
- Drive context menu
- Open drive
- Eject drive where supported
- Open Disk Management

The drive bars were also upgraded with customizable colors so the user can control the visual style of drive usage indicators.

---

## View Modes

Folder view modes were added to make NoxenFE feel more like a real file explorer.

Supported folder view modes:

- Details
- List
- Small icons
- Medium icons
- Large icons
- Extra large icons

The selected view mode is saved in settings.

### Ctrl + Mouse Wheel Icon Zoom

Icon/list views now support Explorer-style zooming with:

```text
Ctrl + Mouse Wheel
```

This changes the icon size while browsing folders.

---

## File Actions and Keyboard Shortcuts

Several normal file-manager actions were added or polished.

Added shortcuts:

- `F2` — Rename selected file/folder
- `Delete` — Move selected file/folder to Recycle Bin
- `Ctrl + L` — Focus/select address bar

Added file actions:

- Open selected item
- Rename file/folder
- Delete to Recycle Bin
- Open file location where possible
- Shortcut target handling
- Archive actions
- ISO actions
- MTP actions

---

## Preview and Details Pane

A preview/details pane was added so NoxenFE can show more information about selected files and folders.

The pane can show file/folder information such as:

- Name
- Path
- Type
- Size
- Modified date
- Basic preview/details information

The preview/details pane can be toggled from the View menu and saved in settings.

---

## Settings Window

The Settings window was expanded during the v2.0 R1 rebuild.

Settings now include options for areas such as:

- Startup behavior
- Session restore
- Default view mode
- Icon size
- Preview/details pane visibility
- Drive bar colors
- Quick Access behavior
- Other UI preferences

Settings are stored so NoxenFE can remember user preferences across launches.

---

## MTP / Phone Device Support

One of the biggest additions in this release is built-in MTP device support.

This allows NoxenFE to browse phones and portable media devices without needing the device to appear as a normal drive letter.

### MTP Support Includes

- Portable device scanning
- MTP phone detection
- MTP device listing in the sidebar / This PC-style areas
- Browsing device folders
- Opening MTP folders
- Refresh / rescan device support
- Reduced background scanning to prevent lag
- Worker-thread scanning so the UI does not freeze as easily

### MTP File Actions

MTP action support was later expanded with:

- Export selected MTP files/folders to a PC folder
- Send local files to the current MTP folder
- Send a local folder to the current MTP folder
- Rename MTP files/folders where supported
- Open current MTP folder in Windows Explorer
- MTP toolbar buttons
- Better MTP context menu grouping

### MTP Feature DLLs

MTP support is split into modular feature DLLs:

```text
Resources\FeatureDLLs\MTPsupport\NoxenMtpDeviceScan.dll
Resources\FeatureDLLs\MTPsupport\NoxenMtpFs.dll
Resources\FeatureDLLs\MTPsupport\NoxenMtpActions.dll
```

This keeps MTP-specific code separate from the main EXE and makes the feature easier to maintain.

---

## Archive Support

Archive support was rebuilt around a bundled 7-Zip runtime.

Users do not need to install 7-Zip separately for NoxenFE archive features to work.

### Supported Archive Actions

Archive context-menu actions include:

- Open archive
- Open archive in 7-Zip File Manager
- Extract Here
- Extract to archive-name folder
- Extract to chosen folder
- Test archive
- Create ZIP archive from selected files/folders
- Create 7Z archive from selected files/folders

### Supported Archive Types

Archive support is powered by 7-Zip, so the supported formats depend on the included 7-Zip runtime.

Common supported formats include:

- `.zip`
- `.7z`
- `.rar` extraction/listing
- `.tar`
- `.gz`
- `.bz2`
- `.xz`
- `.cab`
- `.iso`
- and other formats supported by the bundled 7-Zip version

Note: RAR creation is not supported. 7-Zip can extract/list RAR archives, but RAR compression is proprietary and is not implemented as a create option.

### Bundled 7-Zip Files

The release includes 7-Zip runtime files so archive features work out of the box.

Bundled files include:

```text
7z.exe
7z.dll
7zFM.exe
7-zip.dll
7-zip32.dll
License.txt
```

These files are kept as third-party runtime files in the normal build.

### 7-Zip File Manager Integration

Because 7-Zip redistribution is allowed when the required license information is included, NoxenFE includes an option to open archives in the real 7-Zip File Manager.

Added action:

```text
Archive > Open in 7-Zip File Manager
```

This gives users a familiar full archive viewer without requiring NoxenFE to recreate every part of 7-Zip's interface.

---

## ISO Support

NoxenFE now has ISO tools through the archive/ISO feature system.

ISO actions include:

- Mount ISO
- Dismount ISO
- Open mounted ISO drive where possible

The ISO support is handled separately from normal archive extraction logic.

---

## Shortcut Support

Windows shortcut support was added through a dedicated shortcut feature module.

Shortcut features include:

- Resolve `.lnk` target
- Open shortcut target
- Open shortcut target location
- Create shortcut here
- Double-click `.lnk` attempts to open the real target

This helps NoxenFE behave more like Windows Explorer when working with shortcuts.

---

## Modular Feature DLL System

A big internal change in this release is the new feature DLL structure.

Instead of putting every advanced feature directly inside the main EXE, several feature areas are separated into custom DLLs.

### Archive / ISO / Shortcut DLLs

```text
Resources\FeatureDLLs\ArchiveSupport\NoxenArchiveCore.dll
Resources\FeatureDLLs\ArchiveSupport\NoxenSevenZipBridge.dll
Resources\FeatureDLLs\ArchiveSupport\NoxenArchiveActions.dll
Resources\FeatureDLLs\ArchiveSupport\NoxenIsoTools.dll
Resources\FeatureDLLs\ArchiveSupport\NoxenShortcutTools.dll
```

### MTP DLLs

```text
Resources\FeatureDLLs\MTPsupport\NoxenMtpDeviceScan.dll
Resources\FeatureDLLs\MTPsupport\NoxenMtpFs.dll
Resources\FeatureDLLs\MTPsupport\NoxenMtpActions.dll
```

This makes the project easier to expand later without turning the main EXE into one giant file.

---

## Help Menu Additions

The Help menu was updated for the final release.

Added Help menu items:

- GitHub Page
- NFE Website
- NFE License
- 7-Zip License
- About

The GitHub and website options open the project pages in the user's browser.

The license options open readable license windows inside the app.

---

## About Window Updates

The About window was cleaned up for the final release.

Changes include:

- Removed development phase text
- Shows the final v2.0 R1 identity
- Shows clickable GitHub link
- Shows clickable website link
- Shows project/version information
- Uses the NoxenFE icon/logo

---

## Licensing

### Noxen File Explorer License

NoxenFE is released as closed-source freeware.

That means:

- The program is free to download and use
- The program is intended to stay free
- The source code is not open source
- Redistribution should follow the NFE license included with the release
- Users should not sell, rebrand, claim ownership of, or redistribute modified builds without permission

The full NFE license is included with the release and can be opened from:

```text
Help > NFE License
```

### 7-Zip License

This release includes 7-Zip components.

The 7-Zip license file is included with the release and can be opened from:

```text
Help > 7-Zip License
```

The included 7-Zip license information must remain available with redistributed builds that include 7-Zip files.

---

## Normal Build Layout

The recommended build keeps the runtime files visible and separate.

Example layout:

```text
NoxenFE_RazerNative.exe
Resources\
  FeatureDLLs\
    ArchiveSupport\
      NoxenArchiveCore.dll
      NoxenSevenZipBridge.dll
      NoxenArchiveActions.dll
      NoxenIsoTools.dll
      NoxenShortcutTools.dll
      ThirdParty\
        7zip\
          7z.exe
          7z.dll
          7zFM.exe
          7-zip.dll
          7-zip32.dll
          License.txt
    MTPsupport\
      NoxenMtpDeviceScan.dll
      NoxenMtpFs.dll
      NoxenMtpActions.dll
  NFE_LICENSE.txt
  7ZIP_LICENSE.txt
```

This is the recommended layout for normal installs.

---

## One-File Build Notes

The one-file build is intended for users who want a single EXE download.

The one-file EXE includes the runtime payload internally, then extracts it into the user's local app data folder when launched.

Extraction location:

```text
%LOCALAPPDATA%\Noxen File Explorer\OneFileRuntime\v2_0_R1\
```

This extracted runtime contains the same kind of files as the normal build:

- Main NoxenFE runtime
- Qt runtime files
- Qt platform plugins
- Custom feature DLLs
- MTP DLLs
- Archive support DLLs
- 7-Zip runtime files
- License files
- App resources

This method is used because Windows DLL loading and Qt platform plugins generally require real files on disk.

---

## Build / Development Notes

This release was built as a Visual Studio MSVC project, not a CMake project.

General build stack:

- Visual Studio 2022
- MSVC x64
- Qt 6.10.2 MSVC 2022 x64
- C++17
- Native Windows APIs
- Qt Widgets

Known harmless deployment warnings may appear during Qt deployment, such as missing DirectX shader compiler files:

```text
Cannot find any version of the dxcompiler.dll and dxil.dll.
Cannot find Visual Studio installation directory, VCINSTALLDIR is not set.
```

These warnings are from Qt deployment checks and do not necessarily mean NoxenFE failed to build.

---

## Detailed Development Phase Summary

This section summarizes the major rebuild phases that led to the final v2.0 R1 release.

### Phase 1 — Native Project Foundation

- Created the Visual Studio/MSVC project
- Set up Qt application foundation
- Built the main native window
- Restored basic folder browsing
- Added sidebar/navigation foundation
- Added toolbar/address controls
- Fixed initial Qt/MSVC C++17 configuration issues
- Fixed Qt 6.10 compatibility issues

### Phase 2 — This PC and Drive Support

- Added This PC page
- Added drive tiles
- Added storage usage bars
- Added drive context menu
- Added eject action where supported
- Added Disk Management shortcut
- Added session restore foundation
- Fixed Drives sidebar behavior so it opens This PC

### Phase 3 — Home / Quick Access

- Added Home page
- Added common folder shortcuts
- Added pinned folders
- Added recent locations
- Added settings dialog foundation
- Added saved settings
- Fixed startup token handling

### Phase 4 — Preview Pane and Drive Bar Customization

- Fixed startup behavior so Home opens first and restored tabs load after
- Added preview/details pane
- Added View menu toggle for preview/details
- Added custom drive usage bar colors
- Added settings for drive bar colors

### Phase 5 — App Icon and About Window

- Added NoxenFE app icon
- Added icon resources
- Added About window
- Added logo/icon display in About
- Added remove actions for pinned/recent items
- Added recent files to Home

### Phase 6 — Quick Access Cleanup Tools

- Added remove all pinned folders
- Added clear all recent locations
- Added clear all recent files
- Added clear all Quick Access data
- Added confirmation dialogs for cleanup actions
- Improved sync between Quick Access/Home data and open tabs

### Phase 7 — Built-In MTP Support

- Added MTP device scan system
- Added MTP feature DLLs
- Added MTP folder browsing
- Added portable device listing
- Switched from Shell-only attempts to WPD-based listing where needed
- Reduced scan lag by avoiding constant polling
- Added manual rescan behavior
- Fixed detection problems with normal USB drives
- Fixed MTP folder loading errors
- Added MTP actions later polished in Phase 10

### Phase 8 — Archive / ISO / Shortcut Tools

- Added archive support modules
- Bundled 7-Zip runtime files
- Added archive extraction actions
- Added archive creation actions
- Added archive testing
- Added 7-Zip File Manager integration
- Added ISO mount/dismount tools
- Added shortcut tools
- Added NFE license and 7-Zip license windows
- Added Help menu license buttons

### Phase 9 — View Modes and File Operation Polish

- Added folder view modes
- Added Details/List/Icon view options
- Added saved default view mode
- Added saved icon size
- Added Ctrl + mouse wheel icon zoom
- Added F2 rename
- Added Delete to Recycle Bin
- Added Ctrl+L address bar focus
- Added tab right-click menu
- Added duplicate tab
- Added close other tabs

### Phase 10 — MTP Action Polish

- Added export selected MTP files/folders to PC
- Added send files to current MTP folder
- Added send folder to current MTP folder
- Added rename MTP item support where possible
- Added open current MTP folder in Windows Explorer
- Reorganized MTP context menu
- Added MTP toolbar actions

### Final Release Cleanup

- Removed phase text from About window
- Added final v2.0 R1 branding
- Added clickable GitHub link
- Added clickable website link
- Added Help menu web links
- Added final release packaging
- Added optional one-file EXE project
- Fixed one-file build script issues
- Fixed one-file runtime extraction/launch behavior

---

## Known Notes and Limitations

### MTP Limitations

MTP behavior depends heavily on Windows, the phone, the USB cable, and the device's connection mode.

Some phones may require:

- Unlocking the device
- Allowing file transfer mode
- Trusting the PC
- Reconnecting the USB cable
- Running Rescan Devices inside NoxenFE

Large MTP transfers may be handled by the Windows Shell layer and may continue in the background.

### Archive Limitations

Archive support depends on the bundled 7-Zip runtime.

RAR creation is not supported.

### One-File Build Limitations

The one-file build is still technically extracting a private runtime folder because Qt plugins, DLLs, and external helper EXEs need real files on disk to work correctly.

This is normal for many one-file desktop applications.

### Default File Manager Mode

Replacing Windows Explorer / Win+E behavior is not included in this v2.0 R1 release. That kind of registry integration is risky and should be handled separately later.

---

## Recommended Release Description

Noxen File Explorer: Razer Native v2.0 R1 is the first full native C++ release of NoxenFE. It rebuilds the older Python version into a faster, cleaner Windows file explorer with tabs, Home/Quick Access, This PC drive browsing, view modes, preview/details pane, MTP phone support, built-in archive/ISO/shortcut tools, bundled 7-Zip support, license windows, and an optional one-file EXE build.

This release is freeware and closed source. NFE is free to use and intended to stay free, but the source code is not open source. Third-party 7-Zip license information is included with the release.

---

## Credits

### Noxen File Explorer

Created by **sonic Fan Tech**.

### 7-Zip

7-Zip is created by Igor Pavlov.

7-Zip files are included as third-party components for archive support and 7-Zip File Manager integration. The 7-Zip license is included with this release.

### Qt

This application uses Qt for the native desktop interface.

---

## Final Notes

This release is a major milestone for Noxen File Explorer.

The goal of v2.0 R1 is to turn NFE from an older Python-based file explorer into a cleaner, faster, and more expandable native Windows application.

Future versions can build on this foundation with more polished file operation progress windows, deeper MTP transfer controls, better thumbnail/icon caching, stronger search, installer polish, website integration, and optional Windows Explorer replacement features.
