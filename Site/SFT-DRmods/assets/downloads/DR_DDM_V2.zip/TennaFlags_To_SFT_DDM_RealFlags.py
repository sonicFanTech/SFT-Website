#!/usr/bin/env python3
"""
Convert Tenna Editor's src/data/flags.ts into SFT_DDM_RealFlags.txt for the
DELTARUNE Debug Menu R6 flag viewer.

Usage:
  1. Download/clone https://github.com/tennaproject/tenna-editor
  2. Copy src/data/flags.ts next to this script, or pass its path:
       python TennaFlags_To_SFT_DDM_RealFlags.py path/to/flags.ts
  3. Put the generated SFT_DDM_RealFlags.txt next to the R6 .csx.
  4. Run the R6 .csx in UMT again.

This only builds a readable metadata index. It does not enable save editing.
"""
from pathlib import Path
import re, sys

src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('flags.ts')
if not src.exists():
    raise SystemExit(f'flags.ts not found: {src}')
text = src.read_text(encoding='utf-8', errors='replace')
# Collapse whitespace so metadata objects can be searched across lines.
flat = re.sub(r'\s+', ' ', text)
# Match chunks like [FLAGS.NAME]: { displayName: '...', description: '...', valueType: 'boolean' }
pattern = re.compile(r"\[FLAGS\.([A-Z0-9_]+)\]\s*:\s*\{(.*?)(?=\}\s*,\s*\[FLAGS\.|\}\s*,\s*\};)")

def grab(obj, field):
    m = re.search(field + r"\s*:\s*(['\"])(.*?)\1", obj)
    return m.group(2).replace('\\\'', "'").replace('\\"', '"') if m else ''

lines = [
    '# Generated from Tenna Editor flags.ts',
    '# Format: FLAGS.NAME | Display name | value type | description',
]
count = 0
for name, obj in pattern.findall(flat):
    display = grab(obj, 'displayName') or name
    vtype = grab(obj, 'valueType') or 'unknown'
    desc = grab(obj, 'description')
    # keep each line compact for embedding into GML strings
    desc = re.sub(r'\s+', ' ', desc).strip()
    line = f'FLAGS.{name} | {display} | {vtype} | {desc}'
    if len(line) > 420:
        line = line[:417] + '...'
    lines.append(line)
    count += 1

out = Path('SFT_DDM_RealFlags.txt')
out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(f'Wrote {out} with {count} flags')
