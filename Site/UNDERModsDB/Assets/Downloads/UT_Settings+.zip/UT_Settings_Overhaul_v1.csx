// SFT UNDERTALE Settings Overhaul Mod v1
// Reworked v1 build: tabbed SETTINGS+, fixed title-settings input, localized Settings+ text,
// C-menu SETTINGS/MAIN MENU buttons, PC borders, and split audio settings.

using System;
using System.Collections.Generic;
using System.IO;
using ImageMagick;
using UndertaleModLib.Compiler;
using UndertaleModLib.Util;

EnsureDataLoaded();

// SFT real border support:
// This creates placeholder background assets so the GML always compiles.
// If you choose your extracted UNDERTALE_Borders folder, it replaces the placeholders
// with the real PNGs you provide locally.
EnsureSftBorderBackgrounds();

if (ScriptQuestion("Import real UNDERTALE border PNGs now?\n\nChoose YES if you extracted UNDERTALE_Borders.zip and want this script to inject those PNGs into data.win.\nChoose NO to keep the built-in procedural/fallback PC borders."))
{
    string sftBorderFolder = PromptChooseDirectory();
    if (sftBorderFolder is not null)
    {
        ImportSftBorderBackgrounds(sftBorderFolder);
    }
}

var patches = new Dictionary<string, string>()
{
    ["gml_Object_obj_intromenu_Create_0"] = @"siner_o = 0;
selected = 65;
charname = """";
naming = 3;
selected2 = 0;
selected3 = 0;
q = 0;
global.to_joyconfig = 0;
name = """";
iniread = ossafe_ini_open(""undertale.ini"");

if (ini_section_exists(""General""))
{
    name = ini_read_string(""General"", ""Name"", """");
    love = ini_read_real(""General"", ""Love"", 0);
    time = ini_read_real(""General"", ""Time"", 0);
    kills = ini_read_real(""General"", ""Kills"", 0);
    roome = ini_read_real(""General"", ""Room"", 0);
}

hasname = 0;

if (name != """")
    hasname = 1;

if (hasname == 1)
    global.charname = name;

ossafe_ini_close();
ossafe_ini_open(""undertale.ini"");
m2 = ossafe_file_exists(""file0"");
m3 = ini_read_real(""Toriel"", ""TK"", 0);
m4 = ini_read_real(""Toriel"", ""TS"", 0);
pd = ini_read_real(""Papyrus"", ""PD"", 0);
ud = ini_read_real(""Undyne"", ""UD"", 0);
ad = ini_read_real(""Alphys"", ""AD"", 0);
fd = ini_read_real(""F7"", ""F7"", 0);
fk = ini_read_real(""Flowey"", ""K"", 0);
truereset = ini_read_real(""EndF"", ""EndF"", 0);
ossafe_ini_close();
mlevel = 0;

if (m2 > 0)
{
    if (m2 > 0)
        mlevel = 1;
    
    if (m4 > 0)
        mlevel = 2;
    
    if (pd > 0 && mlevel == 2)
        mlevel = 3;
    
    if (ud > 0 && mlevel == 3)
        mlevel = 4;
    
    if (ad > 0 && mlevel == 4)
        mlevel = 5;
    
    if (fd > 0 && mlevel == 5)
        mlevel = 6;
}

if (truereset > 0)
    mlevel = 7;

if (mlevel == 0)
    menusong = 220;

if (mlevel == 1)
    menusong = 221;

if (mlevel == 2)
    menusong = 222;

if (mlevel == 3)
    menusong = 223;

if (mlevel == 4)
    menusong = 224;

if (mlevel == 5)
    menusong = 225;

if (mlevel == 6)
    menusong = 226;

if (mlevel == 7)
    menusong = 220;

if (mlevel >= 0 && mlevel <= 6)
    caster_loop(menusong, 0.6, 1);

if (mlevel == 7)
    caster_loop(menusong, 0.1, 0.1);

script_execute(scr_namingscreen_setup);

if (global.osflavor >= 3 && !ossafe_file_exists(""file0""))
    ossafe_savedata_save();


// SFT_UT_SETTINGS_OVERHAUL_v1: persistent window/settings defaults
if (!variable_global_exists(""sft_fullscreen""))
    global.sft_fullscreen = 0;

if (!variable_global_exists(""sft_window_scale""))
    global.sft_window_scale = 2;

if (!variable_global_exists(""sft_master_volume""))
    global.sft_master_volume = 10;

if (!variable_global_exists(""sft_music_volume""))
    global.sft_music_volume = 10;

if (!variable_global_exists(""sft_sfx_volume""))
    global.sft_sfx_volume = 10;

if (!variable_global_exists(""sft_settings_from_game""))
    global.sft_settings_from_game = 0;

if (!variable_global_exists(""sft_pc_borders""))
    global.sft_pc_borders = 1;

ossafe_ini_open(""config.ini"");
var sft_fs_i = ini_read_real(""General"", ""sft_fullscreen"", global.sft_fullscreen);
var sft_ws_i = ini_read_real(""General"", ""sft_window_scale"", global.sft_window_scale);
var sft_mv_i = ini_read_real(""General"", ""sft_master_volume"", global.sft_master_volume);
var sft_muv_i = ini_read_real(""General"", ""sft_music_volume"", global.sft_music_volume);
var sft_sfxv_i = ini_read_real(""General"", ""sft_sfx_volume"", global.sft_sfx_volume);
ossafe_ini_close();

global.sft_fullscreen = sft_fs_i;
global.sft_window_scale = sft_ws_i;
global.sft_master_volume = sft_mv_i;
global.sft_music_volume = sft_muv_i;
global.sft_sfx_volume = sft_sfxv_i;
global.sft_pc_borders = 1;

if (global.sft_window_scale < 1)
    global.sft_window_scale = 1;

if (global.sft_window_scale > 4)
    global.sft_window_scale = 4;

if (global.sft_master_volume < 0)
    global.sft_master_volume = 0;

if (global.sft_master_volume > 10)
    global.sft_master_volume = 10;

if (global.sft_music_volume < 0)
    global.sft_music_volume = 0;

if (global.sft_music_volume > 10)
    global.sft_music_volume = 10;

if (global.sft_sfx_volume < 0)
    global.sft_sfx_volume = 0;

if (global.sft_sfx_volume > 10)
    global.sft_sfx_volume = 10;

var sft_audio_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_audio_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_music_volume""))
    sft_audio_v *= global.sft_music_volume / 10;

if (variable_global_exists(""sft_music_count""))
{
    for (var sft_ai = 0; sft_ai < global.sft_music_count; sft_ai += 1)
    {
        if (audio_is_playing(global.sft_music_ref[sft_ai]))
            audio_sound_gain(global.sft_music_ref[sft_ai], global.sft_music_base[sft_ai] * sft_audio_v, 0);
    }
}

application_surface_enable(true);
application_surface_draw_enable(false);

global.screen_border_alpha = 1;
scr_enable_screen_border(1);

if (global.sft_fullscreen == 1)
{
    window_set_fullscreen(1);
}
else
{
    var sft_win_w = 320 * global.sft_window_scale;
    var sft_win_h = 240 * global.sft_window_scale;
    
    if (global.screen_border_id != 0)
        sft_win_w = round(sft_win_h * 16 / 9);
    
    window_set_fullscreen(0);
    window_set_size(sft_win_w, sft_win_h);
    window_center();
}
",

    ["gml_Object_obj_overworldcontroller_Draw_0"] = @"buffer += 1;

if (global.interact == 5)
{
    currentmenu = global.menuno;
    
    if (global.menuno < 6)
        currentspot = global.menucoord[global.menuno];
    
    xx = view_xview[view_current];
    yy = view_yview[view_current] + 10;
    moveyy = yy;
    
    if (obj_mainchara.y > (yy + 120))
        moveyy += 135;
    
    if (global.menuno != 4)
    {
        draw_set_color(c_white);
        ossafe_fill_rectangle(16 + xx, 16 + moveyy, 86 + xx, 70 + moveyy);
        var sft_cbox_bottom = 132;
        
        if (global.menuno == 0)
            sft_cbox_bottom = 183;
        
        ossafe_fill_rectangle(16 + xx, 74 + yy, 146 + xx, sft_cbox_bottom + yy);
        
        if (global.menuno == 1 || global.menuno == 5 || global.menuno == 6)
            ossafe_fill_rectangle(94 + xx, 16 + yy, 266 + xx, 196 + yy);
        
        if (global.menuno == 2)
        {
            var xend = 266;
            
            if (global.language == ""ja"")
                xend += 9;
            
            ossafe_fill_rectangle(94 + xx, 16 + yy, xend + xx, 224 + yy);
        }
        
        if (global.menuno == 3)
            ossafe_fill_rectangle(94 + xx, 16 + yy, 266 + xx, 150 + yy);
        
        if (global.menuno == 7)
            ossafe_fill_rectangle(94 + xx, 16 + yy, 266 + xx, 216 + yy);
        
        draw_set_color(c_black);
        ossafe_fill_rectangle(19 + xx, 19 + moveyy, 83 + xx, 67 + moveyy);
        ossafe_fill_rectangle(19 + xx, 77 + yy, 143 + xx, (sft_cbox_bottom - 3) + yy);
        
        if (global.menuno == 1 || global.menuno == 5 || global.menuno == 6)
            ossafe_fill_rectangle(97 + xx, 19 + yy, 263 + xx, 193 + yy);
        
        if (global.menuno == 2)
        {
            var xend = 263;
            
            if (global.language == ""ja"")
                xend += 9;
            
            ossafe_fill_rectangle(97 + xx, 19 + yy, xend + xx, 221 + yy);
        }
        
        if (global.menuno == 3)
            ossafe_fill_rectangle(97 + xx, 19 + yy, 263 + xx, 147 + yy);
        
        if (global.menuno == 7)
            ossafe_fill_rectangle(97 + xx, 19 + yy, 263 + xx, 213 + yy);
        
        draw_set_color(c_white);
        scr_setfont(fnt_small);
        var numpos = 23 + xx + string_width(""LV  "");
        draw_text(23 + xx, 40 + moveyy, ""LV"");
        draw_text(numpos, 40 + moveyy, string(global.lv));
        draw_text(23 + xx, 49 + moveyy, ""HP"");
        draw_text(numpos, 49 + moveyy, string(global.hp) + ""/"" + string(global.maxhp));
        draw_text(23 + xx, 58 + moveyy, ""G"");
        draw_text(numpos, 58 + moveyy, string(global.gold));
        scr_setfont(fnt_maintext);
        var name0_x = 23 + xx;
        var name0_y = 20 + moveyy;
        var name0_scale = 1;
        
        if (global.language == ""ja"")
        {
            draw_set_font(fnt_ja_curs);
            name0_y += 4;
            name0_scale = 0.5;
        }
        
        draw_text_transformed(name0_x, name0_y, global.charname, name0_scale, name0_scale, 0);
        scr_setfont(fnt_maintext);
        var xx0 = xx;
        
        if (global.language == ""ja"")
            xx0 -= 2;
        
        if (global.item[0] == 0)
            draw_set_color(c_gray);
        
        if (global.menuchoice[0] == 1)
            draw_text(42 + xx0, 84 + yy, scr_gettext(""field_menu_item""));
        
        draw_set_color(c_white);
        
        if (global.menuchoice[1] == 1)
            draw_text(42 + xx, 102 + yy, scr_gettext(""field_menu_stat""));
        
        if (global.menuchoice[2] == 1)
            draw_text(42 + xx, 120 + yy, scr_gettext(""field_menu_cell""));
        
        var sft_c_settings = ""SETTINGS"";
        var sft_c_mainmenu = ""MAIN MENU"";
        
        if (global.language == ""ja"")
        {
            sft_c_settings = ""せってい"";
            sft_c_mainmenu = ""メニューへ"";
        }
        
        if (global.menuno == 0)
        {
            draw_text(42 + xx, 138 + yy, sft_c_settings);
            draw_text(42 + xx, 156 + yy, sft_c_mainmenu);
        }
        
        if (global.menuno == 1 || global.menuno == 5)
        {
            for (i = 0; i < 8; i += 1)
                draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
            
            draw_text(116 + xx, 170 + yy, scr_gettext(""item_menu_use""));
            draw_text(116 + xx + 48, 170 + yy, scr_gettext(""item_menu_info""));
            draw_text(116 + xx + 105, 170 + yy, scr_gettext(""item_menu_drop""));
        }
    }
    
    if (global.menuno == 3)
    {
        for (i = 0; i < 7; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.phonename[i]);
    }
    
    if (global.menuno == 6)
    {
        scr_itemname();
        
        for (i = 0; i < 8; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
    }
    
    if (global.menuno == 7)
    {
        scr_storagename(300);
        
        for (i = 0; i < 10; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
    }
    
    if (global.menuno == 2)
    {
        var stat_x = 108 + xx;
        
        if (global.language == ""ja"")
            stat_x -= 3;
        
        var exp_x = stat_x + 84;
        var kills_x = exp_x;
        var name_y = 32 + yy;
        var lv_y = 62 + yy;
        var hp_y = 78 + yy;
        var at_y = 110 + yy;
        var df_y = 126 + yy;
        var weapon_y = 156 + yy;
        var armor_y = 172 + yy;
        var gold_y = 192 + yy;
        var kills_y = 192 + yy;
        
        if (global.language == ""ja"")
        {
            weapon_y -= 2;
            gold_y += 2;
            kills_y += 2;
        }
        
        draw_text(stat_x, name_y, scr_gettext(""stat_menu_name""));
        draw_text(stat_x, lv_y, scr_gettext(""stat_menu_lv"", string(global.lv)));
        draw_text(stat_x, hp_y, scr_gettext(""stat_menu_hp"", string(global.hp), string(global.maxhp)));
        draw_text(stat_x, at_y, scr_gettext(""stat_menu_at"", string(global.at - 10), string(global.wstrength)));
        draw_text(stat_x, df_y, scr_gettext(""stat_menu_df"", string(global.df - 10), string(global.adef)));
        draw_text(stat_x, weapon_y, scr_gettext(""stat_menu_weapon"", scr_gettext(""item_name_"" + string(global.weapon))));
        var armorname = scr_gettext(""item_name_"" + string(global.armor));
        
        if (global.armor == 64)
            armorname = scr_gettext(""stat_armor_temmie"");
        
        draw_text(stat_x, armor_y, scr_gettext(""stat_menu_armor"", armorname));
        draw_text(stat_x, gold_y, scr_gettext(""stat_menu_gold""));
        
        if (global.kills > 20)
            draw_text(kills_x, kills_y, scr_gettext(""stat_menu_kills"", string(global.kills)));
        
        if (string_length(global.charname) >= 7)
        {
            var x2 = 192 + xx;
            var y2 = 32 + yy;
            var scale = 1;
            
            if (global.language == ""ja"")
            {
                x2 += 16;
                y2 += 20;
                scale = 0.5;
            }
            
            draw_text_transformed(x2, y2, scr_gettext(""stat_menu_namehack""), scale, scale, 0);
        }
        
        draw_text(exp_x, at_y, scr_gettext(""stat_menu_exp"", string(global.xp)));
        
        if (global.lv == 1)
            nextlevel = 10 - global.xp;
        
        if (global.lv == 2)
            nextlevel = 30 - global.xp;
        
        if (global.lv == 3)
            nextlevel = 70 - global.xp;
        
        if (global.lv == 4)
            nextlevel = 120 - global.xp;
        
        if (global.lv == 5)
            nextlevel = 200 - global.xp;
        
        if (global.lv == 6)
            nextlevel = 300 - global.xp;
        
        if (global.lv == 7)
            nextlevel = 500 - global.xp;
        
        if (global.lv == 8)
            nextlevel = 800 - global.xp;
        
        if (global.lv == 9)
            nextlevel = 1200 - global.xp;
        
        if (global.lv == 10)
            nextlevel = 1700 - global.xp;
        
        if (global.lv == 11)
            nextlevel = 2500 - global.xp;
        
        if (global.lv == 12)
            nextlevel = 3500 - global.xp;
        
        if (global.lv == 13)
            nextlevel = 5000 - global.xp;
        
        if (global.lv == 14)
            nextlevel = 7000 - global.xp;
        
        if (global.lv == 15)
            nextlevel = 10000 - global.xp;
        
        if (global.lv == 16)
            nextlevel = 15000 - global.xp;
        
        if (global.lv == 17)
            nextlevel = 25000 - global.xp;
        
        if (global.lv == 18)
            nextlevel = 50000 - global.xp;
        
        if (global.lv == 19)
            nextlevel = 99999 - global.xp;
        
        if (global.lv >= 20)
            nextlevel = 0;
        
        draw_text(exp_x, df_y, scr_gettext(""stat_menu_next"", string(nextlevel)));
    }
    
    if (global.menuno == 4)
    {
        iniread = ossafe_ini_open(""undertale.ini"");
        name = ini_read_string(""General"", ""Name"", scr_gettext(""save_menu_empty""));
        love = ini_read_real(""General"", ""Love"", 0);
        time = ini_read_real(""General"", ""Time"", 1);
        kills = ini_read_real(""General"", ""Kills"", 0);
        roome = ini_read_real(""General"", ""Room"", 0);
        ossafe_ini_close();
        scr_setfont(fnt_maintext);
        draw_set_color(c_white);
        ossafe_fill_rectangle(54 + xx, 49 + yy, 265 + xx, 135 + yy);
        draw_set_color(c_black);
        ossafe_fill_rectangle(57 + xx, 52 + yy, 262 + xx, 132 + yy);
        draw_set_color(c_white);
        
        if (global.menucoord[4] == 2)
            draw_set_color(c_yellow);
        
        minutes = floor(time / 1800);
        seconds = round(((time / 1800) - minutes) * 60);
        
        if (seconds == 60)
            seconds = 59;
        
        if (seconds < 10)
            seconds = ""0"" + string(seconds);
        
        var roomname = scr_roomname(roome);
        var lvtext = scr_gettext(""save_menu_lv"", string(love));
        var timetext = scr_gettext(""save_menu_time"", string(minutes), string(seconds));
        var namesize = string_width(substr(name, 1, 6));
        var lvsize = string_width(lvtext);
        var timesize = string_width(timetext);
        var x_center = xx + 160;
        var lvpos = round((x_center + (namesize / 2)) - (timesize / 2) - (lvsize / 2));
        var namepos = 70 + xx;
        var timepos = 250 + xx;
        
        if (global.language == ""ja"")
        {
            namepos -= 6;
            timepos += 6;
        }
        
        draw_text(namepos, 60 + yy, name);
        draw_text(lvpos, 60 + yy, lvtext);
        draw_text(timepos - timesize, 60 + yy, timetext);
        
        if (global.language == ""ja"")
            scr_drawtext_centered(x_center, 80 + yy, roomname);
        else
            draw_text(namepos, 80 + yy, roomname);
        
        var savepos = xx + 71;
        var returnpos = xx + 161;
        
        if (global.language == ""ja"")
        {
            savepos = xx + 78;
            returnpos = xx + 173;
        }
        
        if (global.menucoord[4] == 0)
            draw_sprite(spr_heartsmall, 0, savepos, yy + 113);
        
        if (global.menucoord[4] == 1)
            draw_sprite(spr_heartsmall, 0, returnpos, yy + 113);
        
        if (global.menucoord[4] < 2)
        {
            draw_text(savepos + 14, yy + 110, scr_gettext(""save_menu_save""));
            draw_text(returnpos + 14, yy + 110, scr_gettext(""save_menu_return""));
        }
        else
        {
            draw_text(xx + 85, yy + 110, scr_gettext(""save_menu_saved""));
            
            if (control_check_pressed(0))
            {
                global.menuno = -1;
                global.interact = 0;
                global.menucoord[4] = 0;
                control_clear(0);
            }
        }
        
        if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(vk_right))
        {
            if (global.menucoord[4] < 2)
            {
                if (global.menucoord[4] == 1)
                    global.menucoord[4] = 0;
                else
                    global.menucoord[4] = 1;
                
                keyboard_clear(vk_left);
                keyboard_clear(vk_right);
            }
        }
        
        if (control_check_pressed(0) && global.menucoord[4] == 0)
        {
            snd_play(snd_save);
            script_execute(scr_save);
            global.menucoord[4] = 2;
            control_clear(0);
        }
        
        if (control_check_pressed(0) && global.menucoord[4] == 1)
        {
            global.menuno = -1;
            global.interact = 0;
            global.menucoord[4] = 0;
            control_clear(0);
        }
        
        if (control_check_pressed(1))
        {
            global.menuno = -1;
            global.interact = 0;
            global.menucoord[4] = 0;
            control_clear(1);
        }
    }
    
    if (global.menuno == 0)
    {
        var heart_y = 88;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        draw_sprite(spr_heartsmall, 0, 28 + xx, heart_y + yy + (18 * global.menucoord[0]));
    }
    
    if (global.menuno == 1)
    {
        var heart_y = 34;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        draw_sprite(spr_heartsmall, 0, 104 + xx, heart_y + yy + (16 * global.menucoord[1]));
    }
    
    if (global.menuno == 3)
    {
        var heart_y = 34;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        draw_sprite(spr_heartsmall, 0, 104 + xx, heart_y + yy + (16 * global.menucoord[3]));
    }
    
    if (global.menuno == 6)
    {
        var heart_y = 34;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        draw_sprite(spr_heartsmall, 0, 104 + xx, heart_y + yy + (16 * global.menucoord[6]));
    }
    
    if (global.menuno == 7)
    {
        var heart_y = 34;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        draw_sprite(spr_heartsmall, 0, 104 + xx, heart_y + yy + (16 * global.menucoord[7]));
    }
    
    if (global.menuno == 5)
    {
        var heart_y = 174;
        
        if (global.language == ""ja"")
            heart_y -= 1;
        
        if (global.menucoord[5] == 0)
            draw_sprite(spr_heartsmall, 0, 104 + xx + (45 * global.menucoord[5]), heart_y + yy);
        
        if (global.menucoord[5] == 1)
            draw_sprite(spr_heartsmall, 0, 104 + xx + ((45 * global.menucoord[5]) + 3), heart_y + yy);
        
        if (global.menucoord[5] == 2)
            draw_sprite(spr_heartsmall, 0, 104 + xx + ((45 * global.menucoord[5]) + 15), heart_y + yy);
    }
    
    if (control_check_pressed(0))
    {
        if (global.menuno == 5)
        {
            if (global.menucoord[5] == 0)
            {
                global.menuno = 9;
                script_execute(scr_itemuseb, global.menucoord[1], global.item[global.menucoord[1]]);
            }
            
            if (global.menucoord[5] == 1)
            {
                global.menuno = 9;
                script_execute(scr_itemdesc, global.item[global.menucoord[1]]);
                script_execute(scr_writetext, 0, ""x"", 0, 0);
            }
            
            if (global.menucoord[5] == 2)
            {
                global.menuno = 9;
                dontthrow = 0;
                
                if (global.item[global.menucoord[1]] != 23 && global.item[global.menucoord[1]] != 27 && global.item[global.menucoord[1]] != 54 && global.item[global.menucoord[1]] != 56 && global.item[global.menucoord[1]] != 57)
                {
                    script_execute(scr_writetext, 12, ""x"", 0, 0);
                }
                else
                {
                    if (global.item[global.menucoord[1]] == 23)
                        script_execute(scr_writetext, 23, ""x"", 0, 0);
                    
                    if (global.item[global.menucoord[1]] == 27)
                    {
                        script_execute(scr_writetext, 0, scr_gettext(""item_drop_27""), 0, 0);
                        
                        if (instance_exists(obj_rarependant))
                        {
                            with (obj_rarependant)
                                con = 1;
                        }
                    }
                    
                    if (global.item[global.menucoord[1]] == 54)
                    {
                        script_execute(scr_writetext, 0, scr_gettext(""item_drop_54""), 0, 0);
                        dontthrow = 1;
                    }
                    
                    if (global.item[global.menucoord[1]] == 56)
                    {
                        if (!instance_exists(obj_undyne_friendc))
                        {
                            script_execute(scr_writetext, 0, scr_gettext(""item_drop_56""), 0, 0);
                            global.flag[494] = 1;
                        }
                        else
                        {
                            global.faceemotion = 1;
                            script_execute(scr_writetext, 0, scr_gettext(""item_drop_56_undyne""), 5, 37);
                            dontthrow = 1;
                        }
                    }
                    
                    if (global.item[global.menucoord[1]] == 57)
                    {
                        script_execute(scr_writetext, 0, scr_gettext(""item_drop_57""), 0, 0);
                        dontthrow = 1;
                    }
                }
                
                if (dontthrow == 0)
                    script_execute(scr_itemshift, global.menucoord[1], 0);
            }
        }
        
        if (global.menuno == 3)
        {
            global.menuno = 9;
            script_execute(scr_itemuseb, global.menucoord[3], global.phone[global.menucoord[3]]);
        }
        
        if (global.menuno == 6)
        {
            global.menuno = 9;
            script_execute(scr_storageget, global.item[global.menucoord[6]], 300);
            
            if (noroom == 0)
            {
                script_execute(scr_writetext, 16, ""x"", 0, 0);
                script_execute(scr_itemshift, global.menucoord[6], 0);
            }
            else
            {
                script_execute(scr_writetext, 19, ""x"", 0, 0);
            }
        }
        
        if (global.menuno == 7)
        {
            global.menuno = 9;
            script_execute(scr_itemget, global.flag[global.menucoord[7] + 300]);
            
            if (noroom == 0)
            {
                script_execute(scr_writetext, 17, ""x"", 0, 0);
                scr_storageshift(global.menucoord[7], 0, 300);
            }
            else
            {
                script_execute(scr_writetext, 18, ""x"", 0, 0);
            }
        }
        
        if (global.menuno == 1)
        {
            global.menuno = 5;
            global.menucoord[5] = 0;
        }
        
        if (global.menuno == 0)
        {
            if (global.menucoord[0] == 3)
            {
                global.sft_settings_from_game = 1;
                global.interact = 6;
                global.menuno = -1;
                instance_create(0, 0, obj_settingsmenu);
                control_clear(0);
            }
            else if (global.menucoord[0] == 4)
            {
                global.interact = 0;
                global.menuno = -1;
                caster_free(all);
                room_goto(room_intromenu);
                control_clear(0);
            }
            else
            {
                global.menuno += (global.menucoord[0] + 1);
            }
        }
        
        if (global.menuno == 3)
        {
            script_execute(scr_phonename);
            global.menucoord[3] = 0;
        }
        
        if (global.menuno == 1)
        {
            if (global.item[0] != 0)
            {
                global.menucoord[1] = 0;
                script_execute(scr_itemname);
            }
            else
            {
                global.menuno = 0;
            }
        }
    }
    
    if (keyboard_check_pressed(vk_up))
    {
        if (global.menuno == 0)
        {
            if (global.menucoord[0] != 0)
                global.menucoord[0] -= 1;
        }
        
        if (global.menuno == 1)
        {
            if (global.menucoord[1] != 0)
                global.menucoord[1] -= 1;
        }
        
        if (global.menuno == 3)
        {
            if (global.menucoord[3] != 0)
                global.menucoord[3] -= 1;
        }
        
        if (global.menuno == 6)
        {
            if (global.menucoord[6] != 0)
                global.menucoord[6] -= 1;
        }
        
        if (global.menuno == 7)
        {
            if (global.menucoord[7] != 0)
                global.menucoord[7] -= 1;
        }
    }
    
    if (keyboard_check_pressed(vk_down))
    {
        if (global.menuno == 0)
        {
            if (global.menucoord[0] == 0)
            {
                if (global.menuchoice[1] != 0)
                    global.menucoord[0] = 1;
                else
                    global.menucoord[0] = 3;
            }
            else if (global.menucoord[0] == 1)
            {
                if (global.menuchoice[2] != 0)
                    global.menucoord[0] = 2;
                else
                    global.menucoord[0] = 3;
            }
            else if (global.menucoord[0] == 2)
            {
                global.menucoord[0] = 3;
            }
            else if (global.menucoord[0] == 3)
            {
                global.menucoord[0] = 4;
            }
        }
        
        if (global.menuno == 1)
        {
            if (global.menucoord[1] != 7)
            {
                if (global.item[global.menucoord[1] + 1] != 0)
                    global.menucoord[1] += 1;
            }
        }
        
        if (global.menuno == 3)
        {
            if (global.menucoord[3] != 7)
            {
                if (global.phone[global.menucoord[3] + 1] != 0)
                    global.menucoord[3] += 1;
            }
        }
        
        if (global.menuno == 6)
        {
            if (global.menucoord[6] != 7)
            {
                if (global.item[global.menucoord[6] + 1] != 0)
                    global.menucoord[6] += 1;
            }
        }
        
        if (global.menuno == 7)
        {
            if (global.menucoord[7] != 9)
            {
                if (global.flag[global.menucoord[7] + 301] != 0)
                    global.menucoord[7] += 1;
            }
        }
    }
    
    if (control_check_pressed(1) && buffer >= 0)
    {
        if (global.menuno == 0)
        {
            global.menuno = -1;
            global.interact = 0;
        }
        else if (global.menuno <= 3)
        {
            global.menuno = 0;
        }
        
        if (global.menuno == 5)
            global.menuno = 1;
    }
    
    if (keyboard_check_pressed(vk_right))
    {
        if (global.menuno == 5)
        {
            if (global.menucoord[5] != 2)
                global.menucoord[5] += 1;
        }
    }
    
    if (keyboard_check_pressed(vk_left))
    {
        if (global.menuno == 5)
        {
            if (global.menucoord[5] != 0)
                global.menucoord[5] -= 1;
        }
    }
    
    if (control_check_pressed(2))
    {
        if (global.menuno == 0)
        {
            global.menuno = -1;
            global.interact = 0;
        }
    }
    
    if (currentmenu < global.menuno && global.menuno != 9)
    {
        snd_play(snd_select);
    }
    else if (global.menuno >= 0 && global.menuno < 6)
    {
        if (currentspot != global.menucoord[global.menuno])
            snd_play(snd_squeak);
    }
}

if (global.menuno == 9 && instance_exists(obj_dialoguer) == 0)
{
    global.menuno = -1;
    global.interact = 0;
}
",

    ["gml_Object_obj_settingsmenu_Create_0"] = @"if (global.to_joyconfig)
{
    global.to_joyconfig = 0;
    instance_create(0, 0, obj_joypadmenu);
    instance_destroy();
    exit;
}

num_borders = 10;
border_enabled[0] = 1;
border_enabled[1] = 1;
border_enabled[2] = 1;
border_enabled[3] = 1;

for (var i = 4; i <= num_borders; i++)
    border_enabled[i] = 0;

fun = 0;

if (ossafe_file_exists(""undertale.ini""))
{
    ossafe_ini_open(""undertale.ini"");
    
    if (ossafe_file_exists(""file0""))
    {
        fun = 1;
        var Won = ini_read_real(""General"", ""Won"", 0);
        var CP = ini_read_real(""General"", ""CP"", 0);
        var CH = ini_read_real(""General"", ""CH"", 0);
        var BW = ini_read_real(""General"", ""BW"", 0);
        var BP = ini_read_real(""General"", ""BP"", 0);
        var BH = ini_read_real(""General"", ""BH"", 0);
        var EndF = ini_read_real(""EndF"", ""EndF"", 0);
        
        if ((Won || BW) || (CP || BP))
        {
            for (var i = 4; i <= 8; i++)
                border_enabled[i] = 1;
        }
        
        if (CP || BP)
            border_enabled[9] = 1;
        
        if (CH || BH)
            border_enabled[10] = 1;
        
        if (EndF >= 2)
            fun = 0;
    }
    
    ossafe_ini_close();
}

menu = 0;
menu_engage = 0;
buffer = 5;
button_list[0] = 32769;
button_list[1] = 32770;
button_list[2] = 32771;
button_list[3] = 32772;
button_list[4] = 32773;
button_list[5] = 32775;
button_list[6] = 32774;
button_list[7] = 32776;
button_list[8] = 32779;
button_list[9] = 32780;
button_list[10] = 32777;
button_list[11] = 32778;
button_list[12] = -4;
r_line = scr_gettext(""joyconfig_resetted"");
o_o = 0;
siner = 0;
r_buffer = 0;
intro = 0;
weather = 0;
rectile = 0;
extreme = 0;
extreme2 = 0;
harp = 0;
weathermusic = 0;

if (fun == 1)
{
    intro = 1;
    menu_engage = -1;
    weather = 1;
    month = current_month;
    
    if (month == 12 || month == 1 || month == 2)
        weather = 1;
    
    if (month == 3 || month == 4 || month == 5)
        weather = 2;
    
    if (month == 6 || month == 7 || month == 8)
        weather = 3;
    
    if (month == 9 || month == 10 || month == 11)
        weather = 4;
}

finish = 0;


// SFT_UT_SETTINGS_OVERHAUL_v1: persistent window/settings defaults
if (!variable_global_exists(""sft_fullscreen""))
    global.sft_fullscreen = 0;

if (!variable_global_exists(""sft_window_scale""))
    global.sft_window_scale = 2;

if (!variable_global_exists(""sft_master_volume""))
    global.sft_master_volume = 10;

if (!variable_global_exists(""sft_music_volume""))
    global.sft_music_volume = 10;

if (!variable_global_exists(""sft_sfx_volume""))
    global.sft_sfx_volume = 10;

if (!variable_global_exists(""sft_settings_from_game""))
    global.sft_settings_from_game = 0;

if (!variable_global_exists(""sft_pc_borders""))
    global.sft_pc_borders = 1;

ossafe_ini_open(""config.ini"");
var sft_fs_i = ini_read_real(""General"", ""sft_fullscreen"", global.sft_fullscreen);
var sft_ws_i = ini_read_real(""General"", ""sft_window_scale"", global.sft_window_scale);
var sft_mv_i = ini_read_real(""General"", ""sft_master_volume"", global.sft_master_volume);
var sft_muv_i = ini_read_real(""General"", ""sft_music_volume"", global.sft_music_volume);
var sft_sfxv_i = ini_read_real(""General"", ""sft_sfx_volume"", global.sft_sfx_volume);
ossafe_ini_close();

global.sft_fullscreen = sft_fs_i;
global.sft_window_scale = sft_ws_i;
global.sft_master_volume = sft_mv_i;
global.sft_music_volume = sft_muv_i;
global.sft_sfx_volume = sft_sfxv_i;
global.sft_pc_borders = 1;

if (global.sft_window_scale < 1)
    global.sft_window_scale = 1;

if (global.sft_window_scale > 4)
    global.sft_window_scale = 4;

if (global.sft_master_volume < 0)
    global.sft_master_volume = 0;

if (global.sft_master_volume > 10)
    global.sft_master_volume = 10;

if (global.sft_music_volume < 0)
    global.sft_music_volume = 0;

if (global.sft_music_volume > 10)
    global.sft_music_volume = 10;

if (global.sft_sfx_volume < 0)
    global.sft_sfx_volume = 0;

if (global.sft_sfx_volume > 10)
    global.sft_sfx_volume = 10;

application_surface_enable(true);
application_surface_draw_enable(false);

global.screen_border_alpha = 1;
scr_enable_screen_border(1);

if (global.sft_fullscreen == 1)
{
    window_set_fullscreen(1);
}
else
{
    var sft_win_w = 320 * global.sft_window_scale;
    var sft_win_h = 240 * global.sft_window_scale;
    
    if (global.screen_border_id != 0)
        sft_win_w = round(sft_win_h * 16 / 9);
    
    window_set_fullscreen(0);
    window_set_size(sft_win_w, sft_win_h);
    window_center();
}


// SFT_UT_SETTINGS_OVERHAUL_v1: Settings+ state.
for (var sft_b = 0; sft_b <= num_borders; sft_b += 1)
    border_enabled[sft_b] = 1;

fun = 0;
intro = 0;
menu_engage = 0;
weather = 0;
harp = 0;
weathermusic = 0;
rectile = 0;
extreme = 0;
extreme2 = 0;

sft_page = 0;
sft_menu = 0;
sft_notice = """";
sft_notice_timer = 0;
sft_page_count = 4;
",

    ["gml_Object_obj_settingsmenu_Draw_0"] = @"var sft_from_game = 0;

if (variable_global_exists(""sft_settings_from_game""))
    sft_from_game = global.sft_settings_from_game;

var sft_draw_x = 0;
var sft_draw_y = 0;

if (sft_from_game == 1)
{
    sft_draw_x = view_xview[view_current];
    sft_draw_y = view_yview[view_current];
}

// Text labels. Existing UNDERTALE settings keys use scr_gettext; new Settings+ labels swap manually.
var tx_title = ""SETTINGS+"";
var tx_page = ""PAGE"";
var tx_general = ""GENERAL"";
var tx_video = ""VIDEO"";
var tx_audio = ""AUDIO"";
var tx_controls = ""CONTROLS"";
var tx_exit = scr_gettext(""joyconfig_exit"");
var tx_save = ""SAVE CONFIG"";
var tx_mainmenu = ""MAIN MENU"";
var tx_fullscreen = ""FULLSCREEN"";
var tx_window = ""WINDOW SIZE"";
var tx_master = ""MASTER"";
var tx_music = ""MUSIC"";
var tx_sfx = ""SOUND"";
var tx_reset = scr_gettext(""joyconfig_reset"");
var tx_on = ""ON"";
var tx_off = ""OFF"";
var tx_titleonly = ""TITLE ONLY"";
var tx_help1 = ""UP/DOWN = MOVE   LEFT/RIGHT = CHANGE"";
var tx_help2 = ""Z = OK / NEXT TAB   X = BACK"";

if (global.language == ""ja"")
{
    tx_title = ""せってい+"";
    tx_page = ""ページ"";
    tx_general = ""ぜんぱん"";
    tx_video = ""がめん"";
    tx_audio = ""おんりょう"";
    tx_controls = ""そうさ"";
    tx_save = ""ほぞん"";
    tx_mainmenu = ""メニューへ"";
    tx_fullscreen = ""フルスクリーン"";
    tx_window = ""おおきさ"";
    tx_master = ""ぜんたい"";
    tx_music = ""おんがく"";
    tx_sfx = ""こうかおん"";
    tx_on = ""オン"";
    tx_off = ""オフ"";
    tx_titleonly = ""タイトルのみ"";
    tx_help1 = ""じょうげ = えらぶ   さゆう = かえる"";
    tx_help2 = ""Z = けってい / つぎ   X = もどる"";
}

var page_name = tx_general;

if (sft_page == 1)
    page_name = tx_video;

if (sft_page == 2)
    page_name = tx_audio;

if (sft_page == 3)
    page_name = tx_controls;

var sft_menu_max = 0;

if (sft_page == 0)
{
    sft_menu_max = 3;
    if (sft_from_game == 1)
        sft_menu_max = 4;
}

if (sft_page == 1)
    sft_menu_max = 3;

if (sft_page == 2)
    sft_menu_max = 3;

if (sft_page == 3)
    sft_menu_max = 2;

draw_set_color(c_black);
ossafe_fill_rectangle(sft_draw_x, sft_draw_y, sft_draw_x + 320, sft_draw_y + 240);

draw_set_color(c_white);
scr_setfont(fnt_maintext);
scr_drawtext_centered_scaled(sft_draw_x + 160, sft_draw_y + 5, tx_title, 2, 2);

// Small tab strip.
scr_setfont(fnt_small);
var tab_y = sft_draw_y + 35;
var tab_x = sft_draw_x + 20;

if (sft_page == 0)
    draw_set_color(c_yellow);
else
    draw_set_color(c_gray);
draw_text(tab_x, tab_y, tx_general);

if (sft_page == 1)
    draw_set_color(c_yellow);
else
    draw_set_color(c_gray);
draw_text(tab_x + 68, tab_y, tx_video);

if (sft_page == 2)
    draw_set_color(c_yellow);
else
    draw_set_color(c_gray);
draw_text(tab_x + 128, tab_y, tx_audio);

if (sft_page == 3)
    draw_set_color(c_yellow);
else
    draw_set_color(c_gray);
draw_text(tab_x + 196, tab_y, tx_controls);

scr_setfont(fnt_maintext);
var label_x = sft_draw_x + 42;
var value_x = sft_draw_x + 178;
var start_y = sft_draw_y + 58;
var step_y = 20;
var yy0 = 0;
var label = """";
var value = """";

for (var i = 0; i <= sft_menu_max; i += 1)
{
    yy0 = start_y + (i * step_y);
    label = """";
    value = """";
    
    if (i == 0)
    {
        label = tx_page;
        value = ""< "" + page_name + "" >"";
    }
    
    if (sft_page == 0)
    {
        if (i == 1)
            label = tx_exit;
        
        if (i == 2)
        {
            label = scr_gettext(""settings_language"");
            value = scr_gettext(""settings_language_"" + global.language);
        }
        
        if (i == 3)
            label = tx_save;
        
        if (i == 4)
            label = tx_mainmenu;
    }
    
    if (sft_page == 1)
    {
        if (i == 1)
        {
            label = tx_fullscreen;
            if (global.sft_fullscreen == 1)
                value = tx_on;
            else
                value = tx_off;
        }
        
        if (i == 2)
        {
            label = tx_window;
            value = string(global.sft_window_scale) + ""X"";
        }
        
        if (i == 3)
        {
            label = scr_gettext(""settings_border"");
            if (global.screen_border_id == 0)
                value = scr_gettext(""settings_border_none"");
            else if (global.screen_border_id == 1)
                value = ""LINE"";
            else if (global.screen_border_id == 2)
                value = ""CHARA"";
            else if (global.screen_border_id == 3)
                value = ""AUTO"";
            else if (global.screen_border_id == 4)
                value = ""RUINS"";
            else if (global.screen_border_id == 5)
                value = ""SNOWDIN"";
            else if (global.screen_border_id == 6)
                value = ""WATERFALL"";
            else if (global.screen_border_id == 7)
                value = ""HOTLAND"";
            else if (global.screen_border_id == 8)
                value = ""CASTLE"";
            else if (global.screen_border_id == 9)
                value = ""TRUE LAB"";
            else if (global.screen_border_id == 10)
                value = ""SPECIAL"";
        }
    }
    
    if (sft_page == 2)
    {
        if (i == 1)
        {
            label = tx_master;
            value = string(global.sft_master_volume * 10) + ""%"";
        }
        
        if (i == 2)
        {
            label = tx_music;
            value = string(global.sft_music_volume * 10) + ""%"";
        }
        
        if (i == 3)
        {
            label = tx_sfx;
            value = string(global.sft_sfx_volume * 10) + ""%"";
        }
    }
    
    if (sft_page == 3)
    {
        if (i == 1)
        {
            label = scr_gettext(""settings_joyconfig"");
            if (sft_from_game == 1)
                value = tx_titleonly;
        }
        
        if (i == 2)
            label = tx_reset;
    }
    
    if (sft_menu == i)
    {
        draw_set_color(c_yellow);
        draw_sprite(spr_heartsmall, 0, sft_draw_x + 22, yy0 + 4);
    }
    else
    {
        draw_set_color(c_white);
    }
    
    draw_text(label_x, yy0, label);
    
    if (string_length(value) > 0)
        draw_text(value_x, yy0, value);
}

scr_setfont(fnt_small);
draw_set_color(c_gray);
draw_text(sft_draw_x + 20, sft_draw_y + 205, tx_help1);
draw_text(sft_draw_x + 20, sft_draw_y + 216, tx_help2);

if (sft_notice_timer > 0)
{
    sft_notice_timer -= 1;
    draw_set_color(c_yellow);
    draw_text(sft_draw_x + 20, sft_draw_y + 228, sft_notice);
}
",

    ["gml_Object_obj_settingsmenu_Step_0"] = @"buffer -= 1;

var sft_from_game = 0;

if (variable_global_exists(""sft_settings_from_game""))
    sft_from_game = global.sft_settings_from_game;

if (!variable_global_exists(""sft_fullscreen""))
    global.sft_fullscreen = 0;

if (!variable_global_exists(""sft_window_scale""))
    global.sft_window_scale = 2;

if (!variable_global_exists(""sft_master_volume""))
    global.sft_master_volume = 10;

if (!variable_global_exists(""sft_music_volume""))
    global.sft_music_volume = 10;

if (!variable_global_exists(""sft_sfx_volume""))
    global.sft_sfx_volume = 10;

if (!variable_global_exists(""sft_pc_borders""))
    global.sft_pc_borders = 1;

global.sft_pc_borders = 1;
global.screen_border_alpha = 1;
application_surface_enable(true);
application_surface_draw_enable(false);

if (window_get_fullscreen())
    global.sft_fullscreen = 1;
else
    global.sft_fullscreen = 0;

if (global.sft_window_scale < 1)
    global.sft_window_scale = 1;

if (global.sft_window_scale > 4)
    global.sft_window_scale = 4;

if (global.sft_master_volume < 0)
    global.sft_master_volume = 0;

if (global.sft_master_volume > 10)
    global.sft_master_volume = 10;

if (global.sft_music_volume < 0)
    global.sft_music_volume = 0;

if (global.sft_music_volume > 10)
    global.sft_music_volume = 10;

if (global.sft_sfx_volume < 0)
    global.sft_sfx_volume = 0;

if (global.sft_sfx_volume > 10)
    global.sft_sfx_volume = 10;

var sft_menu_max = 0;

if (sft_page == 0)
{
    sft_menu_max = 3;
    if (sft_from_game == 1)
        sft_menu_max = 4;
}

if (sft_page == 1)
    sft_menu_max = 3;

if (sft_page == 2)
    sft_menu_max = 3;

if (sft_page == 3)
    sft_menu_max = 2;

if (keyboard_check_pressed(vk_down))
    sft_menu += 1;

if (keyboard_check_pressed(vk_up))
    sft_menu -= 1;

if (sft_menu < 0)
    sft_menu = sft_menu_max;

if (sft_menu > sft_menu_max)
    sft_menu = 0;

var sft_left = keyboard_check_pressed(vk_left);
var sft_right = keyboard_check_pressed(vk_right);
var sft_accept = 0;
var sft_do_save = 0;
var sft_do_apply_window = 0;
var sft_do_audio_apply = 0;

if (buffer < 0 && control_check_pressed(0))
{
    sft_accept = 1;
    buffer = 4;
}

if (sft_menu == 0 && (sft_left || sft_right || sft_accept == 1))
{
    if (sft_left)
        sft_page -= 1;
    else
        sft_page += 1;
    
    if (sft_page < 0)
        sft_page = sft_page_count - 1;
    
    if (sft_page >= sft_page_count)
        sft_page = 0;
    
    sft_menu = 0;
}
else
{
    if (sft_page == 0)
    {
        if (sft_menu == 1 && sft_accept == 1)
            finish = 1;
        
        if (sft_menu == 2 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (global.language == ""en"")
                global.language = ""ja"";
            else
                global.language = ""en"";
            
            if (global.language == ""ja"")
                sft_notice = ""げんごを かえました"";
            else
                sft_notice = ""Language changed."";
            
            sft_notice_timer = 45;
        }
        
        if (sft_menu == 3 && sft_accept == 1)
        {
            sft_do_save = 1;
        }
        
        if (sft_menu == 4 && sft_accept == 1 && sft_from_game == 1)
        {
            sft_do_save = 1;
            global.sft_settings_from_game = 0;
            global.interact = 0;
            global.menuno = -1;
            caster_free(all);
            room_goto(room_intromenu);
            exit;
        }
    }
    
    if (sft_page == 1)
    {
        if (sft_menu == 1 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (global.sft_fullscreen == 1)
                global.sft_fullscreen = 0;
            else
                global.sft_fullscreen = 1;
            
            sft_do_apply_window = 1;
            sft_do_save = 1;
        }
        
        if (sft_menu == 2 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (sft_left)
                global.sft_window_scale -= 1;
            else
                global.sft_window_scale += 1;
            
            if (global.sft_window_scale < 1)
                global.sft_window_scale = 4;
            
            if (global.sft_window_scale > 4)
                global.sft_window_scale = 1;
            
            sft_do_apply_window = 1;
            sft_do_save = 1;
        }
        
        if (sft_menu == 3 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (sft_left)
                global.screen_border_id -= 1;
            else
                global.screen_border_id += 1;
            
            if (global.screen_border_id < 0)
                global.screen_border_id = num_borders;
            
            if (global.screen_border_id > num_borders)
                global.screen_border_id = 0;
            
            global.screen_border_state = 0;
            global.screen_border_dynamic_fade_id = 0;
            global.screen_border_dynamic_fade_level = 0;
            global.screen_border_alpha = 1;
            scr_enable_screen_border(1);
            sft_do_apply_window = 1;
            sft_do_save = 1;
        }
    }
    
    if (sft_page == 2)
    {
        if (sft_menu == 1 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (sft_left)
                global.sft_master_volume -= 1;
            else
                global.sft_master_volume += 1;
            
            if (global.sft_master_volume < 0)
                global.sft_master_volume = 10;
            
            if (global.sft_master_volume > 10)
                global.sft_master_volume = 0;
            
            sft_do_save = 1;
            sft_do_audio_apply = 1;
        }
        
        if (sft_menu == 2 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (sft_left)
                global.sft_music_volume -= 1;
            else
                global.sft_music_volume += 1;
            
            if (global.sft_music_volume < 0)
                global.sft_music_volume = 10;
            
            if (global.sft_music_volume > 10)
                global.sft_music_volume = 0;
            
            sft_do_save = 1;
            sft_do_audio_apply = 1;
        }
        
        if (sft_menu == 3 && (sft_accept == 1 || sft_left || sft_right))
        {
            if (sft_left)
                global.sft_sfx_volume -= 1;
            else
                global.sft_sfx_volume += 1;
            
            if (global.sft_sfx_volume < 0)
                global.sft_sfx_volume = 10;
            
            if (global.sft_sfx_volume > 10)
                global.sft_sfx_volume = 0;
            
            sft_do_save = 1;
            snd_play(snd_squeak);
        }
    }
    
    if (sft_page == 3)
    {
        if (sft_menu == 1 && sft_accept == 1)
        {
            if (sft_from_game == 1)
            {
                if (global.language == ""ja"")
                    sft_notice = ""タイトルから ひらいてください"";
                else
                    sft_notice = ""Open this from title settings."";
                
                sft_notice_timer = 55;
            }
            else
            {
                jc = instance_create(0, 0, obj_joypadmenu);
                jc.menu_engage = 0;
                jc.buffer = buffer;
                jc.intro = intro;
                jc.rectile = rectile;
                jc.weather = weather;
                jc.extreme = extreme;
                jc.extreme2 = extreme2;
                jc.harp = harp;
                jc.weathermusic = weathermusic;
                instance_destroy();
                exit;
            }
        }
        
        if (sft_menu == 2 && sft_accept == 1)
        {
            global.button0 = global.default_button0;
            global.button1 = global.default_button1;
            global.button2 = global.default_button2;
            global.analog_sense = global.default_analog_sense;
            global.analog_sense_sense = global.default_analog_sense_sense;
            global.joy_dir = global.default_joy_dir;
            sft_do_save = 1;
            
            if (global.language == ""ja"")
                sft_notice = ""ボタンを リセットしました"";
            else
                sft_notice = ""Controller buttons reset."";
            
            sft_notice_timer = 45;
        }
    }
}

if (sft_do_audio_apply == 1)
{
    var sft_audio_v = 1;
    
    if (variable_global_exists(""sft_master_volume""))
        sft_audio_v *= global.sft_master_volume / 10;
    
    if (variable_global_exists(""sft_music_volume""))
        sft_audio_v *= global.sft_music_volume / 10;
    
    if (variable_global_exists(""sft_music_count""))
    {
        for (var sft_ai = 0; sft_ai < global.sft_music_count; sft_ai += 1)
        {
            if (audio_is_playing(global.sft_music_ref[sft_ai]))
                audio_sound_gain(global.sft_music_ref[sft_ai], global.sft_music_base[sft_ai] * sft_audio_v, 0);
        }
    }
}

if (sft_do_apply_window == 1)
{
    if (global.sft_fullscreen == 1)
    {
        window_set_fullscreen(1);
    }
    else
    {
        var sft_win_w = 320 * global.sft_window_scale;
        var sft_win_h = 240 * global.sft_window_scale;
        
        if (global.screen_border_id != 0)
            sft_win_w = round(sft_win_h * 16 / 9);
        
        window_set_fullscreen(0);
        window_set_size(sft_win_w, sft_win_h);
        window_center();
    }
    
    global.screen_border_alpha = 1;
    scr_enable_screen_border(1);
}

if (sft_do_save == 1)
{
    ossafe_ini_open(""config.ini"");
    ini_write_string(""General"", ""lang"", global.language);
    ini_write_real(""General"", ""sb"", global.screen_border_id);
    ini_write_real(""General"", ""sft_fullscreen"", global.sft_fullscreen);
    ini_write_real(""General"", ""sft_window_scale"", global.sft_window_scale);
    ini_write_real(""General"", ""sft_master_volume"", global.sft_master_volume);
    ini_write_real(""General"", ""sft_music_volume"", global.sft_music_volume);
    ini_write_real(""General"", ""sft_sfx_volume"", global.sft_sfx_volume);
    ini_write_real(""joypad1"", ""b0"", global.button0);
    ini_write_real(""joypad1"", ""b1"", global.button1);
    ini_write_real(""joypad1"", ""b2"", global.button2);
    ini_write_real(""joypad1"", ""as"", global.analog_sense);
    ini_write_real(""joypad1"", ""jd"", global.joy_dir);
    ossafe_ini_close();
    ossafe_savedata_save();
    
    if (global.language == ""ja"")
        sft_notice = ""config.ini に ほぞんしました"";
    else
        sft_notice = ""Saved to config.ini."";
    
    sft_notice_timer = 45;
}

if (control_check_pressed(1) && buffer < 0)
{
    finish = 1;
    control_clear(1);
}

if (finish)
{
    ossafe_ini_open(""config.ini"");
    ini_write_string(""General"", ""lang"", global.language);
    ini_write_real(""General"", ""sb"", global.screen_border_id);
    ini_write_real(""General"", ""sft_fullscreen"", global.sft_fullscreen);
    ini_write_real(""General"", ""sft_window_scale"", global.sft_window_scale);
    ini_write_real(""General"", ""sft_master_volume"", global.sft_master_volume);
    ini_write_real(""General"", ""sft_music_volume"", global.sft_music_volume);
    ini_write_real(""General"", ""sft_sfx_volume"", global.sft_sfx_volume);
    ini_write_real(""joypad1"", ""b0"", global.button0);
    ini_write_real(""joypad1"", ""b1"", global.button1);
    ini_write_real(""joypad1"", ""b2"", global.button2);
    ini_write_real(""joypad1"", ""as"", global.analog_sense);
    ini_write_real(""joypad1"", ""jd"", global.joy_dir);
    ossafe_ini_close();
    ossafe_savedata_save();
    
    if (sft_from_game == 1)
    {
        global.sft_settings_from_game = 0;
        global.interact = 5;
        global.menuno = 0;
        global.menucoord[0] = 3;
        instance_destroy();
        exit;
    }
    
    caster_free(all);
    room_goto(room_intromenu);
}
",

    ["gml_Object_obj_time_Create_0"] = @"if (os_type == os_windows)
    global.osflavor = 1;
else if (os_type == os_ps4 || os_type == os_psvita)
    global.osflavor = 4;
else
    global.osflavor = 2;

global.locale = os_get_language() + ""_"" + string_upper(os_get_region());

if (global.osflavor >= 3)
{
    application_surface_enable(true);
    application_surface_draw_enable(false);
}

global.savedata_async_id = -1;
global.savedata_async_load = 0;
global.savedata_error = 0;
global.savedata_debuginfo = """";
global.disable_os_pause = 0;
paused = 0;
idle = 0;
idle_time = 0;
up = 0;
down = 0;
left = 0;
right = 0;
quit = 0;
try_up = 0;
try_down = 0;
try_left = 0;
try_right = 0;
canquit = 1;
h_skip = 0;
j_xpos = 0;
j_ypos = 0;
j_dir = 0;
j_fr = 0;
j_fl = 0;
j_fu = 0;
j_fd = 0;
j_fr_p = 0;
j_fl_p = 0;
j_fu_p = 0;
j_fd_p = 0;

for (var i = 0; i < 12; i += 1)
{
    j_prev[i] = 0;
    j_on[i] = 0;
}

global.button0 = 2;
global.button1 = 1;
global.button2 = 4;
global.analog_sense = 0.15;
global.analog_sense_sense = 0.01;
global.joy_dir = 0;

if (os_type == os_ps4 || os_type == os_psvita)
{
    if (substr(global.locale, 1, 2) == ""ja"")
    {
        global.button0 = gp_face2;
        global.button1 = gp_face1;
    }
    else
    {
        global.button0 = gp_face1;
        global.button1 = gp_face2;
    }
    
    global.button2 = gp_face4;
}

global.default_button0 = global.button0;
global.default_button1 = global.button1;
global.default_button2 = global.button2;
global.default_analog_sense = global.analog_sense;
global.default_analog_sense_sense = global.analog_sense_sense;
global.default_joy_dir = global.joy_dir;
global.screen_border_id = 0;
global.screen_border_active = 0;
global.screen_border_alpha = 1;
global.screen_border_state = 0;
global.screen_border_dynamic_fade_id = 0;
global.screen_border_dynamic_fade_level = 0;
global.screen_border_activate_on_game_over = 0;
debug_r = 0;
debug_f = 0;
j1 = 0;
j2 = 0;
ja = 0;
j_ch = 0;
jt = 0;

if (global.osflavor >= 4)
{
    j_ch = 1;
    
    for (var i = 0; i < gamepad_get_device_count(); i++)
    {
        if (gamepad_is_connected(i))
            j_ch = i + 1;
    }
}

spec_rtimer = 0;
global.endsong_loaded = 0;
control_init();
scr_kanatype_init();

if (!variable_global_exists(""text_data_en""))
    script_execute(textdata_en);

if (!variable_global_exists(""text_data_ja""))
    script_execute(textdata_ja);

global.language = substr(global.locale, 1, 2);

if (global.language != ""ja"")
    global.language = ""en"";

if (!variable_global_exists(""trophy_init_complete""))
{
    global.trophy_init_complete = 0;
    trophy_ts = -1;
}


// SFT_UT_SETTINGS_OVERHAUL_v1: defaults for Settings+.
if (!variable_global_exists(""sft_fullscreen""))
    global.sft_fullscreen = 0;

if (!variable_global_exists(""sft_window_scale""))
    global.sft_window_scale = 2;

if (!variable_global_exists(""sft_master_volume""))
    global.sft_master_volume = 10;

if (!variable_global_exists(""sft_music_volume""))
    global.sft_music_volume = 10;

if (!variable_global_exists(""sft_sfx_volume""))
    global.sft_sfx_volume = 10;

if (!variable_global_exists(""sft_pc_borders""))
    global.sft_pc_borders = 1;

if (!variable_global_exists(""sft_settings_from_game""))
    global.sft_settings_from_game = 0;

// PC needs manual app-surface drawing for console borders to be visible.
application_surface_enable(true);
application_surface_draw_enable(false);
global.screen_border_alpha = 1;
",

    ["gml_Object_obj_time_Draw_77"] = @"if (global.osflavor >= 3 || (variable_global_exists(""sft_pc_borders"") && global.sft_pc_borders == 1))
{
    var ww = window_get_width();
    var wh = window_get_height();
    var sw = surface_get_width(application_surface);
    var sh = surface_get_height(application_surface);
    var xx = floor((ww - (sw * global.window_scale)) / 2);
    var yy = floor((wh - (sh * global.window_scale)) / 2);
    global.window_xofs = xx;
    global.window_yofs = yy;
    texture_set_interpolation(false);
    
    if (global.screen_border_active && global.screen_border_alpha > 0)
    {
        scr_draw_screen_border(global.screen_border_id);
        
        if (global.screen_border_alpha < 1)
        {
            draw_set_alpha(1 - global.screen_border_alpha);
            draw_set_color(c_black);
            ossafe_fill_rectangle(0, 0, ww - 1, wh - 1);
            draw_set_alpha(1);
            draw_set_color(c_white);
        }
    }
    
    draw_enable_alphablend(0);
    draw_surface_ext(application_surface, xx, yy, global.window_scale, global.window_scale, 0, c_white, 1);
    draw_enable_alphablend(1);
}
else
{
    global.window_xofs = 0;
    global.window_yofs = 0;
}

if (started < 0 && trophy_ts > 0 && (current_time - trophy_ts) >= 2000)
{
    scr_setfont(fnt_main);
    var lineheight = 32;
    
    if (global.language == ""ja"")
        lineheight = 36;
    
    var line1 = scr_gettext(""trophy_install"");
    var dot = scr_gettext(""trophy_install_dot"");
    var line2 = scr_gettext(""trophy_install_line2"");
    var width1 = string_width(line1 + dot + dot + dot);
    var width2 = string_width(line2);
    var width = max(width1, width2);
    var xx = window_get_width() - 10 - width;
    var yy = 10;
    
    for (var i = 0; i < (floor((current_time - trophy_ts) / 500) % 4); i++)
        line1 += dot;
    
    draw_set_color(c_white);
    draw_text(xx, yy, line1);
    draw_text(xx, yy + lineheight, line2);
}
",

    ["gml_Object_obj_time_Step_1"] = @"if (started <= 0)
{
    if (global.savedata_async_id >= 0)
        exit;
    
    started = -1;
    
    if (!trophy_init())
    {
        if (trophy_ts < 0)
            trophy_ts = current_time;
        
        exit;
    }
    
    ossafe_ini_open(""config.ini"");
    var lang = ini_read_string(""General"", ""lang"", """");
    var sb_i = ini_read_real(""General"", ""sb"", -1);
    var b0_i = ini_read_real(""joypad1"", ""b0"", -1);
    var b1_i = ini_read_real(""joypad1"", ""b1"", -1);
    var b2_i = ini_read_real(""joypad1"", ""b2"", -1);
    var as_i = ini_read_real(""joypad1"", ""as"", -1);
    var jd_i = ini_read_real(""joypad1"", ""jd"", -1);
    var sft_fs_i = ini_read_real(""General"", ""sft_fullscreen"", global.sft_fullscreen);
    var sft_ws_i = ini_read_real(""General"", ""sft_window_scale"", global.sft_window_scale);
    var sft_mv_i = ini_read_real(""General"", ""sft_master_volume"", global.sft_master_volume);
    var sft_muv_i = ini_read_real(""General"", ""sft_music_volume"", global.sft_music_volume);
    var sft_sfxv_i = ini_read_real(""General"", ""sft_sfx_volume"", global.sft_sfx_volume);
    
    if (string_length(lang) > 0)
        global.language = lang;
    
    if (sb_i >= 0)
        global.screen_border_id = sb_i;
    
    if (b0_i >= 0)
        global.button0 = b0_i;
    
    if (b1_i >= 0)
        global.button1 = b1_i;
    
    if (b2_i >= 0)
        global.button2 = b2_i;
    
    if (as_i >= 0)
        global.analog_sense = as_i;
    
    if (jd_i >= 0)
        global.joy_dir = jd_i;
    
    global.sft_fullscreen = sft_fs_i;
    global.sft_window_scale = sft_ws_i;
    global.sft_master_volume = sft_mv_i;
    global.sft_music_volume = sft_muv_i;
    global.sft_sfx_volume = sft_sfxv_i;
    global.sft_pc_borders = 1;
    
    if (global.sft_window_scale < 1)
        global.sft_window_scale = 1;
    
    if (global.sft_window_scale > 4)
        global.sft_window_scale = 4;
    
    if (global.sft_master_volume < 0)
        global.sft_master_volume = 0;
    
    if (global.sft_master_volume > 10)
        global.sft_master_volume = 10;
    
    if (global.sft_music_volume < 0)
        global.sft_music_volume = 0;
    
    if (global.sft_music_volume > 10)
        global.sft_music_volume = 10;
    
    if (global.sft_sfx_volume < 0)
        global.sft_sfx_volume = 0;
    
    if (global.sft_sfx_volume > 10)
        global.sft_sfx_volume = 10;
    
    var sft_audio_v = 1;
    
    if (variable_global_exists(""sft_master_volume""))
        sft_audio_v *= global.sft_master_volume / 10;
    
    if (variable_global_exists(""sft_music_volume""))
        sft_audio_v *= global.sft_music_volume / 10;
    
    if (variable_global_exists(""sft_music_count""))
    {
        for (var sft_ai = 0; sft_ai < global.sft_music_count; sft_ai += 1)
        {
            if (audio_is_playing(global.sft_music_ref[sft_ai]))
                audio_sound_gain(global.sft_music_ref[sft_ai], global.sft_music_base[sft_ai] * sft_audio_v, 0);
        }
    }
    
    ossafe_ini_close();
    global.screen_border_alpha = 1;
    scr_enable_screen_border(1);
    application_surface_enable(true);
    application_surface_draw_enable(false);
    
    if (global.sft_fullscreen == 1)
    {
        window_set_fullscreen(1);
    }
    else
    {
        var sft_win_w = 320 * global.sft_window_scale;
        var sft_win_h = 240 * global.sft_window_scale;
        
        if (global.screen_border_id != 0)
            sft_win_w = round(sft_win_h * 16 / 9);
        
        window_set_fullscreen(0);
        window_set_size(sft_win_w, sft_win_h);
        window_center();
    }
    
    if (global.osflavor >= 4)
    {
        global.analog_sense = 0.15;
        
        if (os_type == os_psvita)
            global.analog_sense = 0.9;
        
        global.joy_dir = 0;
    }
    
    ossafe_ini_open(""undertale.ini"");
    fskip = ini_read_real(""FFFFF"", ""E"", -1);
    ftime = ini_read_real(""FFFFF"", ""F"", -1);
    true_end = ini_read_real(""EndF"", ""EndF"", -1);
    ossafe_ini_close();
    sksk = 0;
    
    if (ftime == 1)
    {
        sksk = 1;
        room_goto(room_f_start);
    }
    
    if (true_end == 1 && sksk == 0)
    {
        sksk = 1;
        room_goto(room_flowey_regret);
    }
    
    if (fskip >= 1 && sksk == 0)
    {
        global.filechoice = 8;
        scr_load();
        
        if (fskip == 1)
            room_goto(room_flowey_endchoice);
        
        if (fskip == 2)
            room_goto(room_castle_exit);
    }
    else if (sksk == 0)
    {
        room_goto_next();
    }
    
    if (ossafe_file_exists(""system_information_962"") && !ossafe_file_exists(""system_information_963""))
        room_goto(room_nothingness);
    
    started = 1;
    exit;
}

if (!paused)
    time += 1;

if (global.osflavor <= 2)
{
    if (jt == 0)
    {
        if (j_ch != 2)
        {
            if (joystick_exists(1))
                j_ch = 1;
            else if (j_ch == 1)
                j_ch = 0;
        }
    }
    
    if (jt == 4)
    {
        if (j_ch != 1)
        {
            if (joystick_exists(2))
                j_ch = 2;
            else if (j_ch == 2)
                j_ch = 0;
        }
    }
    
    jt += 1;
    
    if (jt >= 8)
        jt = 0;
}

control_update();

if (j_ch > 0)
{
    j_fr_p = j_fr;
    j_fl_p = j_fl;
    j_fu_p = j_fu;
    j_fd_p = j_fd;
    j_fr = 0;
    j_fl = 0;
    j_fu = 0;
    j_fd = 0;
    
    if (global.osflavor >= 4)
    {
        if (gamepad_button_check(j_ch - 1, gp_padu) || gamepad_button_check(j_ch - 1, gp_padd) || gamepad_button_check(j_ch - 1, gp_padl) || gamepad_button_check(j_ch - 1, gp_padr))
        {
            j_fu = gamepad_button_check(j_ch - 1, gp_padu);
            j_fd = gamepad_button_check(j_ch - 1, gp_padd);
            j_fl = gamepad_button_check(j_ch - 1, gp_padl);
            j_fr = gamepad_button_check(j_ch - 1, gp_padr);
        }
        else if (global.joy_dir != 2)
        {
            var j_xpos = gamepad_axis_value(j_ch - 1, gp_axislh);
            var j_ypos = gamepad_axis_value(j_ch - 1, gp_axislv);
            var analog_sense = global.analog_sense;
            
            if (sqrt(sqr(j_xpos) + sqr(j_ypos)) >= analog_sense)
            {
                var angle = darctan2(j_ypos, j_xpos);
                
                if (angle < 0)
                    angle += 360;
                
                if (angle < 67.5 || angle > 292.5)
                    j_fr = 1;
                
                if (angle > 22.5 && angle < 157.5)
                    j_fd = 1;
                
                if (angle > 112.5 && angle < 247.5)
                    j_fl = 1;
                
                if (angle > 202.5 && angle < 337.5)
                    j_fu = 1;
            }
        }
    }
    else
    {
        var j_xpos, j_ypos;
        
        if (global.joy_dir == 0 || global.joy_dir == 1)
        {
            j_xpos = joystick_xpos(j_ch);
            j_ypos = joystick_ypos(j_ch);
        }
        
        j_dir = joystick_direction(j_ch);
        
        if (global.joy_dir == 0 || global.joy_dir == 1)
        {
            if (j_dir == 101)
            {
                if (j_xpos >= global.analog_sense)
                    j_fr = 1;
                
                if (j_xpos <= -global.analog_sense)
                    j_fl = 1;
                
                if (j_ypos >= global.analog_sense)
                    j_fd = 1;
                
                if (j_ypos <= -global.analog_sense)
                    j_fu = 1;
            }
        }
        
        if (j_dir != 101)
        {
            if (j_dir == 100)
                j_fl = 1;
            
            if (j_dir == 98)
                j_fd = 1;
            
            if (j_dir == 102)
                j_fr = 1;
            
            if (j_dir == 104)
                j_fu = 1;
            
            if (j_dir == 99)
            {
                j_fr = 1;
                j_fd = 1;
            }
            
            if (j_dir == 97)
            {
                j_fd = 1;
                j_fl = 1;
            }
            
            if (j_dir == 103)
            {
                j_fu = 1;
                j_fl = 1;
            }
            
            if (j_dir == 105)
            {
                j_fu = 1;
                j_fr = 1;
            }
        }
        
        if (global.joy_dir == 0 || global.joy_dir == 2)
        {
            j_pov = joystick_pov(j_ch);
            
            if (j_pov == 0)
                j_fu = 1;
            
            if (j_pov == 270)
                j_fl = 1;
            
            if (j_pov == 90)
                j_fr = 1;
            
            if (j_pov == 180)
                j_fd = 1;
            
            if (j_pov == 315)
            {
                j_fu = 1;
                j_fl = 1;
            }
            
            if (j_pov == 45)
            {
                j_fu = 1;
                j_fr = 1;
            }
            
            if (j_pov == 225)
            {
                j_fd = 1;
                j_fl = 1;
            }
            
            if (j_pov == 135)
            {
                j_fd = 1;
                j_fr = 1;
            }
        }
    }
    
    if (j_fr != j_fr_p && j_fr == 1)
        keyboard_key_press(vk_right);
    
    if (j_fl != j_fl_p && j_fl == 1)
        keyboard_key_press(vk_left);
    
    if (j_fd != j_fd_p && j_fd == 1)
        keyboard_key_press(vk_down);
    
    if (j_fu != j_fu_p && j_fu == 1)
        keyboard_key_press(vk_up);
    
    if (j_fr != j_fr_p && j_fr == 0)
        keyboard_key_release(vk_right);
    
    if (j_fl != j_fl_p && j_fl == 0)
        keyboard_key_release(vk_left);
    
    if (j_fd != j_fd_p && j_fd == 0)
        keyboard_key_release(vk_down);
    
    if (j_fu != j_fu_p && j_fu == 0)
        keyboard_key_release(vk_up);
}

up = 0;
down = 0;
left = 0;
right = 0;

if (keyboard_check(vk_up))
    try_up = 1;

if (keyboard_check_released(vk_up))
    try_up = 0;

if (keyboard_check(vk_down))
    try_down = 1;

if (keyboard_check_released(vk_down))
    try_down = 0;

if (keyboard_check(vk_right))
    try_right = 1;

if (keyboard_check_released(vk_right))
    try_right = 0;

if (keyboard_check(vk_left))
    try_left = 1;

if (keyboard_check_released(vk_left))
    try_left = 0;

if (global.osflavor == 1)
{
    if (try_up)
        up = keyboard_check_direct(vk_up);
    
    if (try_down)
        down = keyboard_check_direct(vk_down);
    
    if (try_left)
        left = keyboard_check_direct(vk_left);
    
    if (try_right)
        right = keyboard_check_direct(vk_right);
}
else
{
    if (try_up)
        up = keyboard_check(vk_up);
    
    if (try_down)
        down = keyboard_check(vk_down);
    
    if (try_left)
        left = keyboard_check(vk_left);
    
    if (try_right)
        right = keyboard_check(vk_right);
}

if (keyboard_check_released(vk_up))
    up = 0;

if (keyboard_check_released(vk_down))
    down = 0;

if (keyboard_check_released(vk_left))
    left = 0;

if (keyboard_check_released(vk_right))
    right = 0;

var now_idle = !(up || down || left || right || control_check(0) || control_check(1) || control_check(2));

if (now_idle && !idle)
    idle_time = current_time;

idle = now_idle;

if (control_check(2))
{
    if (global.flag[28] == 1)
    {
        if (instance_exists(OBJ_WRITER) && !instance_exists(obj_choicer))
        {
            if (h_skip == 0)
            {
                keyboard_key_press(ord(""X""));
                keyboard_key_press(ord(""Z""));
            }
            
            if (h_skip == 1)
            {
                keyboard_key_release(ord(""Z""));
                keyboard_key_release(ord(""X""));
            }
            
            if (h_skip == 0)
                h_skip = 1;
            else
                h_skip = 0;
        }
    }
}

if (global.debug == 1)
{
    if (keyboard_check_pressed(ord(""F"")))
        room_speed = 200;
}

if (global.debug == 1)
{
    if (keyboard_check_pressed(ord(""W"")))
        room_speed = 10;
}

if (keyboard_check_pressed(vk_f4))
{
    if (window_get_fullscreen())
        window_set_fullscreen(false);
    else
        window_set_fullscreen(true);
}

if (canquit == 1)
{
    if (global.debug == 1)
    {
        if (keyboard_check_pressed(ord(""R"")) && instance_exists(obj_essaystuff) == 0)
        {
            debug_r += 1;
            
            if (debug_r > 5)
                game_restart();
            
            spec_rtimer = 1;
        }
    }
    
    spec_rtimer += 1;
    
    if (spec_rtimer >= 6)
        debug_r = 0;
    
    if (keyboard_check(vk_escape))
    {
        quit += 1;
        
        if (instance_exists(obj_quittingmessage) == 0)
            instance_create(0, 0, obj_quittingmessage);
    }
    else
    {
        quit = 0;
    }
}
",

    ["gml_Script_caster_get_volume"] = @"if (variable_global_exists(""sft_music_count""))
{
    for (var sft_ai = 0; sft_ai < global.sft_music_count; sft_ai += 1)
    {
        if (global.sft_music_ref[sft_ai] == argument0)
            return global.sft_music_base[sft_ai];
    }
}

var sft_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_music_volume""))
    sft_v *= global.sft_music_volume / 10;

if (sft_v <= 0)
    return 0;

return audio_sound_get_gain(argument0) / sft_v;
",

    ["gml_Script_caster_loop"] = @"var sft_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_music_volume""))
    sft_v *= global.sft_music_volume / 10;

this_song_i = audio_play_sound(argument0, 120, true);
audio_sound_pitch(this_song_i, argument2);
audio_sound_pitch(argument0, argument2);
audio_sound_gain(this_song_i, argument1 * sft_v, 0);
audio_sound_gain(argument0, argument1 * sft_v, 0);

if (!variable_global_exists(""sft_music_count""))
    global.sft_music_count = 0;

if (global.sft_music_count > 240)
    global.sft_music_count = 0;

global.sft_music_ref[global.sft_music_count] = this_song_i;
global.sft_music_base[global.sft_music_count] = argument1;
global.sft_music_count += 1;
return this_song_i;
",

    ["gml_Script_caster_play"] = @"var sft_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_music_volume""))
    sft_v *= global.sft_music_volume / 10;

this_song_i = audio_play_sound(argument0, 100, false);
audio_sound_pitch(this_song_i, argument2);
audio_sound_pitch(argument0, argument2);
audio_sound_gain(this_song_i, argument1 * sft_v, 0);
audio_sound_gain(argument0, argument1 * sft_v, 0);

if (!variable_global_exists(""sft_music_count""))
    global.sft_music_count = 0;

if (global.sft_music_count > 240)
    global.sft_music_count = 0;

global.sft_music_ref[global.sft_music_count] = this_song_i;
global.sft_music_base[global.sft_music_count] = argument1;
global.sft_music_count += 1;
return this_song_i;
",

    ["gml_Script_caster_set_volume"] = @"var sft_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_music_volume""))
    sft_v *= global.sft_music_volume / 10;

audio_sound_gain(argument0, argument1 * sft_v, 0);

if (!variable_global_exists(""sft_music_count""))
    global.sft_music_count = 0;

var sft_found = 0;

for (var sft_ai = 0; sft_ai < global.sft_music_count; sft_ai += 1)
{
    if (global.sft_music_ref[sft_ai] == argument0)
    {
        global.sft_music_base[sft_ai] = argument1;
        sft_found = 1;
    }
}

if (sft_found == 0)
{
    if (global.sft_music_count > 240)
        global.sft_music_count = 0;
    
    global.sft_music_ref[global.sft_music_count] = argument0;
    global.sft_music_base[global.sft_music_count] = argument1;
    global.sft_music_count += 1;
}
",

    ["gml_Script_caster_free"] = @"if (argument0 != all)
{
    audio_stop_sound(argument0);
}
else
{
    audio_stop_all();
    
    if (variable_global_exists(""sft_music_count""))
        global.sft_music_count = 0;
}
",

    ["gml_Script_scr_draw_background_ps4"] = @"var bg = argument0;
var xx = argument1;
var yy = argument2;
var scale = window_get_width() / 1920;
var scale_h = window_get_height() / 1080;

if (scale_h > scale)
    scale = scale_h;

draw_background_stretched(bg, xx * scale, yy * scale, background_get_width(bg) * scale, background_get_height(bg) * scale);
",

    ["gml_Script_scr_draw_screen_border"] = @"var border_id = argument0;
draw_enable_alphablend(0);

var ww = window_get_width();
var wh = window_get_height();
var sw = surface_get_width(application_surface);
var sh = surface_get_height(application_surface);
var sc = global.window_scale;

if (sc <= 0)
    sc = 1;

var game_w = sw * sc;
var game_h = sh * sc;
var gx = floor((ww - game_w) / 2);
var gy = floor((wh - game_h) / 2);

if (border_id == 3)
{
    var room_id = global.currentroom;
    border_id = 1;
    
    if ((room_id >= room_area1 && room_id <= room_ruinsexit) || (room >= room_introstory && room <= room_intromenu) || (room >= room_settings && room <= room_controltest))
        border_id = 4;
    
    if ((room_id >= room_tundra1 && room_id <= room_fogroom) || room_id == room_shop1 || (room_id >= room_icecave1 && room_id <= room_ice_dog))
        border_id = 5;
    
    if ((room_id >= room_water1 && room_id <= room_water_undynefinal3) || room_id == room_shop2 || room_id == room_shop5)
        border_id = 6;
    
    if ((room_id >= room_fire1 && room_id <= room_fire_finalelevator) || room_id == room_shop3 || room_id == room_shop4 || (room_id >= room_fire_labelevator && room_id <= room_truelab_elevatorinside))
        border_id = 7;
    
    if (room_id >= room_castle_elevatorout && room_id <= room_castle_trueexit)
        border_id = 8;
    
    if (room_id >= room_truelab_elevator && room_id <= room_truelab_power)
        border_id = 9;
    
    if (room_id == room_water_undynefinal3 || room_id == room_fire_elevator || room_id == room_fire_finalelevator || room_id == room_fire_labelevator || room_id == room_truelab_elevatorinside || room_id == room_riverman_transition || room_id == room_dogshrine)
        border_id = 2;
    
    if (global.flag[479] == 0 && (room_id == room_truelab_elevator || room_id == room_truelab_hall1))
        border_id = 2;
}

if (border_id == 0)
{
    draw_enable_alphablend(1);
    exit;
}

// Real imported border backgrounds. The CSX creates these names before this code is compiled.
var sft_bg = bg_sft_border_line;

if (border_id == 1)
    sft_bg = bg_sft_border_line;

if (border_id == 2)
    sft_bg = bg_sft_border_chara;

if (border_id == 4)
    sft_bg = bg_sft_border_ruins;

if (border_id == 5)
    sft_bg = bg_sft_border_snowdin;

if (border_id == 6)
    sft_bg = bg_sft_border_waterfall;

if (border_id == 7)
    sft_bg = bg_sft_border_hotland;

if (border_id == 8)
    sft_bg = bg_sft_border_castle;

if (border_id == 9)
    sft_bg = bg_sft_border_true_lab;

if (border_id == 10)
    sft_bg = bg_sft_border_special;

// Width > 4 means a real user-provided PNG was imported.
// Width <= 4 means it is just the placeholder asset, so use the procedural fallback below.
if (background_get_width(sft_bg) > 4)
{
    draw_set_color(c_white);
    draw_set_alpha(1);
    draw_background_stretched(sft_bg, 0, 0, ww, wh);
    draw_enable_alphablend(1);
    exit;
}

var base_col = c_black;
var side_col = make_color_rgb(25, 25, 25);
var line_col = make_color_rgb(70, 70, 70);
var accent_col = make_color_rgb(120, 120, 120);

if (border_id == 1)
{
    base_col = c_black;
    side_col = make_color_rgb(18, 18, 18);
    line_col = make_color_rgb(80, 80, 80);
    accent_col = make_color_rgb(150, 150, 150);
}

if (border_id == 2)
{
    base_col = make_color_rgb(18, 13, 6);
    side_col = make_color_rgb(54, 38, 18);
    line_col = make_color_rgb(113, 80, 38);
    accent_col = make_color_rgb(198, 160, 80);
}

if (border_id == 4)
{
    base_col = make_color_rgb(20, 4, 32);
    side_col = make_color_rgb(55, 20, 75);
    line_col = make_color_rgb(110, 65, 145);
    accent_col = make_color_rgb(198, 145, 255);
}

if (border_id == 5)
{
    base_col = make_color_rgb(6, 18, 34);
    side_col = make_color_rgb(20, 55, 90);
    line_col = make_color_rgb(78, 135, 185);
    accent_col = make_color_rgb(190, 230, 255);
}

if (border_id == 6)
{
    base_col = make_color_rgb(2, 12, 42);
    side_col = make_color_rgb(8, 45, 90);
    line_col = make_color_rgb(0, 115, 160);
    accent_col = make_color_rgb(0, 230, 255);
}

if (border_id == 7)
{
    base_col = make_color_rgb(28, 4, 0);
    side_col = make_color_rgb(92, 20, 0);
    line_col = make_color_rgb(165, 55, 0);
    accent_col = make_color_rgb(255, 150, 32);
}

if (border_id == 8)
{
    base_col = make_color_rgb(8, 8, 14);
    side_col = make_color_rgb(48, 48, 58);
    line_col = make_color_rgb(115, 112, 130);
    accent_col = make_color_rgb(235, 220, 130);
}

if (border_id == 9)
{
    base_col = make_color_rgb(2, 25, 15);
    side_col = make_color_rgb(10, 70, 45);
    line_col = make_color_rgb(35, 140, 95);
    accent_col = make_color_rgb(120, 255, 180);
}

if (border_id == 10)
{
    base_col = make_color_hsv((current_time / 80) % 255, 120, 35);
    side_col = make_color_hsv((current_time / 80) % 255, 180, 80);
    line_col = make_color_hsv(((current_time / 80) + 50) % 255, 200, 150);
    accent_col = make_color_hsv(((current_time / 80) + 100) % 255, 220, 255);
}

draw_set_color(base_col);
ossafe_fill_rectangle(0, 0, ww - 1, wh - 1);

draw_set_color(side_col);
ossafe_fill_rectangle(0, 0, gx - 1, wh - 1);
ossafe_fill_rectangle(gx + game_w, 0, ww - 1, wh - 1);
ossafe_fill_rectangle(0, 0, ww - 1, gy - 1);
ossafe_fill_rectangle(0, gy + game_h, ww - 1, wh - 1);

draw_set_color(line_col);
ossafe_fill_rectangle(gx - 4, gy - 4, gx + game_w + 3, gy - 1);
ossafe_fill_rectangle(gx - 4, gy + game_h, gx + game_w + 3, gy + game_h + 3);
ossafe_fill_rectangle(gx - 4, gy - 4, gx - 1, gy + game_h + 3);
ossafe_fill_rectangle(gx + game_w, gy - 4, gx + game_w + 3, gy + game_h + 3);

draw_set_color(line_col);
for (var _border_y = 0; _border_y < wh; _border_y += 24)
{
    ossafe_fill_rectangle(0, _border_y, max(0, gx - 12), _border_y + 2);
    ossafe_fill_rectangle(gx + game_w + 12, _border_y, ww - 1, _border_y + 2);
}

for (var _border_x = 0; _border_x < ww; _border_x += 32)
{
    ossafe_fill_rectangle(_border_x, 0, _border_x + 2, max(0, gy - 8));
    ossafe_fill_rectangle(_border_x, gy + game_h + 8, _border_x + 2, wh - 1);
}

draw_set_color(accent_col);
var tile = 28;
var xo = 12 + (floor(current_time / 400) % 2) * 8;

for (var y2 = 20; y2 < wh; y2 += tile * 2)
{
    ossafe_fill_rectangle(max(0, gx - 80), y2, max(0, gx - 60), y2 + 4);
    ossafe_fill_rectangle(max(0, gx - 80), y2 + 4, max(0, gx - 76), y2 + 24);
    ossafe_fill_rectangle(gx + game_w + 60, y2 + xo, gx + game_w + 80, y2 + xo + 4);
    ossafe_fill_rectangle(gx + game_w + 76, y2 + xo + 4, gx + game_w + 80, y2 + xo + 24);
}

if (border_id == 1)
{
    draw_set_color(c_white);
    ossafe_fill_rectangle(gx - 8, gy - 8, gx + game_w + 7, gy - 5);
    ossafe_fill_rectangle(gx - 8, gy + game_h + 5, gx + game_w + 7, gy + game_h + 8);
    ossafe_fill_rectangle(gx - 8, gy - 8, gx - 5, gy + game_h + 8);
    ossafe_fill_rectangle(gx + game_w + 5, gy - 8, gx + game_w + 8, gy + game_h + 8);
}

if (border_id == 3.5)
{
    draw_set_color(c_black);
    ossafe_fill_rectangle(0, 0, ww - 1, wh - 1);
}

draw_set_color(c_white);
draw_set_alpha(1);
draw_enable_alphablend(1);
"
,

    ["gml_Script_snd_play"] = @"var sft_snd = audio_play_sound(argument0, 80, false);
var sft_v = 1;

if (variable_global_exists(""sft_master_volume""))
    sft_v *= global.sft_master_volume / 10;

if (variable_global_exists(""sft_sfx_volume""))
    sft_v *= global.sft_sfx_volume / 10;

audio_sound_gain(sft_snd, sft_v, 0);
return sft_snd;
"
};


Dictionary<string, string> GetSftBorderAssetNames()
{
    return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        ["bg_sft_border_line"] = "",
        ["bg_sft_border_chara"] = "OTHER/01.png",
        ["bg_sft_border_ruins"] = "DYNAMIC/RUINS_BORDER.png",
        ["bg_sft_border_snowdin"] = "DYNAMIC/SONWDIN_BORDER.png",
        ["bg_sft_border_waterfall"] = "DYNAMIC/WATERFALL_BORDER.png",
        ["bg_sft_border_hotland"] = "DYNAMIC/HOTELAND_BORDER.png",
        ["bg_sft_border_castle"] = "DYNAMIC/DYNAMIC_BORDER_5.png",
        ["bg_sft_border_true_lab"] = "DYNAMIC/DYNAMIC_BORDER_6.png",
        ["bg_sft_border_special"] = "OTHER/02.png",
    };
}

void EnsureSftBorderBackgrounds()
{
    foreach (string assetName in GetSftBorderAssetNames().Keys)
    {
        if (Data.Backgrounds.ByName(assetName) is null)
            CreateOrReplaceSftBackground(assetName, null);
    }
}

void ImportSftBorderBackgrounds(string rootFolder)
{
    int importedCount = 0;
    foreach (var pair in GetSftBorderAssetNames())
    {
        string assetName = pair.Key;
        string relName = pair.Value;
        if (string.IsNullOrWhiteSpace(relName))
            continue;
        
        string fileName = Path.GetFileName(relName);
        string found = FindSftBorderFile(rootFolder, fileName);
        
        if (found is not null)
        {
            CreateOrReplaceSftBackground(assetName, found);
            importedCount++;
        }
    }
    
    ScriptMessage($"SFT Settings+ imported {importedCount} border background PNG(s).\n\nIf this says 0, extract UNDERTALE_Borders.zip first and run the script again, selecting the extracted UNDERTALE_Borders folder.");
}

string FindSftBorderFile(string rootFolder, string fileName)
{
    foreach (string path in Directory.GetFiles(rootFolder, "*.png", SearchOption.AllDirectories))
    {
        if (string.Equals(Path.GetFileName(path), fileName, StringComparison.OrdinalIgnoreCase))
            return path;
    }
    return null;
}

void CreateOrReplaceSftBackground(string backgroundName, string pngPath)
{
    MagickImage img;
    if (pngPath is null)
    {
        img = new MagickImage(MagickColors.Transparent, 1, 1);
    }
    else
    {
        img = TextureWorker.ReadBGRAImageFromFile(pngPath);
    }
    
    using (img)
    {
        UndertaleEmbeddedTexture texture = new();
        texture.Name = new UndertaleString($"Texture {Data.EmbeddedTextures.Count}");
        texture.TextureData.Image = GMImage.FromMagickImage(img).ConvertToPng();
        Data.EmbeddedTextures.Add(texture);
        
        UndertaleTexturePageItem texturePageItem = new();
        texturePageItem.Name = new UndertaleString($"PageItem {Data.TexturePageItems.Count}");
        texturePageItem.SourceX = 0;
        texturePageItem.SourceY = 0;
        texturePageItem.SourceWidth = (ushort)img.Width;
        texturePageItem.SourceHeight = (ushort)img.Height;
        texturePageItem.TargetX = 0;
        texturePageItem.TargetY = 0;
        texturePageItem.TargetWidth = (ushort)img.Width;
        texturePageItem.TargetHeight = (ushort)img.Height;
        texturePageItem.BoundingWidth = (ushort)img.Width;
        texturePageItem.BoundingHeight = (ushort)img.Height;
        texturePageItem.TexturePage = texture;
        Data.TexturePageItems.Add(texturePageItem);
        
        UndertaleBackground background = Data.Backgrounds.ByName(backgroundName);
        if (background is null)
        {
            background = new();
            background.Name = Data.Strings.MakeString(backgroundName);
            Data.Backgrounds.Add(background);
        }
        
        background.Transparent = false;
        background.Preload = false;
        background.Texture = texturePageItem;
        Project?.MarkAssetForExport(background);
    }
}

var importGroup = new CodeImportGroup(Data)
{
    MainThreadAction = MainThreadAction
};

foreach (var patch in patches)
{
    importGroup.QueueReplace(patch.Key, patch.Value);
}

importGroup.Import();
ScriptMessage("SFT UNDERTALE Settings Overhaul Mod v1 installed. Save data.win, then launch UNDERTALE.");
