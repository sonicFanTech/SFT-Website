SFT UNDERTALE SETTINGS+ MOD v1
================================

Mod name: SFT UNDERTALE Settings+ Mod
Version: v1
Game: UNDERTALE PC
Tool needed: UndertaleModTool / UMT
Main script: UT_Settings_Overhaul_v1.csx


WHAT THIS MOD DOES
------------------
SFT UNDERTALE Settings+ Mod v1 expands UNDERTALE's basic settings screen into a more useful Settings+ menu and adds quality-of-life options to the in-game C Menu.

The mod keeps the normal UNDERTALE feel, font style, and black-and-white menu look, but adds settings that are easier to reach while playing.

Main features:

- Replaces/overhauls the normal title-screen settings room, room_settings.
- Adds a Settings+ option to the in-game C Menu.
- Adds a Main Menu option to the in-game C Menu.
- Uses tabbed settings pages so the menu is easier to read.
- Saves extra settings to UNDERTALE's normal config.ini file.
- Supports real border image importing from a local UNDERTALE_Borders folder.
- Includes fallback/procedural borders so the mod can still run without imported PNG border files.
- Includes separate audio controls for Master, Music, and SFX volume.


SETTINGS PAGES
--------------
Settings+ is split into pages/tabs.

General page:

- Language
  Changes the game's language setting where supported by UNDERTALE.

- Save Config
  Writes the current Settings+ options to UNDERTALE's config.ini.


Video page:

- Fullscreen
  Toggles fullscreen mode on or off.

- Window Size
  Changes the game window scale.
  Available values are 1X, 2X, 3X, and 4X.

- Border
  Selects the PC border style used around the game view.
  If real border PNGs are imported, the selected border can use those images.
  If real border PNGs are not imported, the mod uses built-in fallback/procedural border drawing.


Audio page:

- Master Volume
  Controls the overall volume used by Settings+ audio handling.

- Music Volume
  Controls music/caster music volume.

- SFX Volume
  Controls normal sound effect volume.

Volume values are shown as simple levels. 100 is full volume, 0 is muted.


Controls page:

- Joystick Config
  Opens UNDERTALE's joystick configuration.

- Reset Controls
  Resets the control settings back to defaults.


IN-GAME C MENU CHANGES
----------------------
This mod adds two useful entries to the normal in-game C Menu:

- SETTINGS
  Opens the Settings+ menu while you are already in-game.

- MAIN MENU
  Sends you back to the main/title menu without needing to close the game window.

Important note:
The Main Menu option does not save your game first. Use a save point before returning to the main menu if you do not want to lose progress.

The added C Menu entries are only meant to appear on the main C Menu page. They should not cover item text, dialogue boxes, or other sub-menus.


CONFIG FILE LOCATION
--------------------
UNDERTALE stores its settings here on Windows:

C:\Users\<Your Windows Username>\AppData\Local\UNDERTALE\config.ini

Settings+ saves extra values into this same config.ini file.

Extra values used by this mod include:

- sft_fullscreen
- sft_window_scale
- sft_master_volume
- sft_music_volume
- sft_sfx_volume

You normally do not need to edit these by hand. Use Settings+ in-game instead.


INSTALLATION
------------
1. Make a backup of your UNDERTALE data.win file.

   This is very important. If something goes wrong, restore the backup instead of trying to repair a broken data.win.

2. Open UNDERTALE's data.win in UndertaleModTool.

3. In UndertaleModTool, go to:

   Scripts -> Run other script...

4. Select:

   UT_Settings_Overhaul_v1.csx

5. The script will ask if you want to import real UNDERTALE border PNGs.

   Choose YES if you have extracted UNDERTALE_Borders.zip and want the real border images imported.
   Choose NO if you want to use the built-in fallback/procedural borders.

6. If you chose YES, select the extracted UNDERTALE_Borders folder.

   Do not select the zip file itself.
   Extract the zip first, then select the folder that contains the border PNG files/folders.

7. Wait for the script to finish.

8. Save the modified data.win in UndertaleModTool.

9. Launch UNDERTALE and test:

   - Title screen Settings menu
   - In-game C Menu -> SETTINGS
   - In-game C Menu -> MAIN MENU
   - Settings+ -> Video -> Border
   - Settings+ -> Audio -> Master/Music/SFX Volume


BORDER IMAGE IMPORTING
----------------------
The mod can work with or without real border PNGs.

Without real border PNGs:

- The mod still works.
- Border options use fallback/procedural drawing.
- This is the safest setup if you are sharing a public package without extra game assets.

With real border PNGs:

- Extract UNDERTALE_Borders.zip first.
- Run the CSX installer.
- Choose YES when asked about importing real border PNGs.
- Select the extracted UNDERTALE_Borders folder.
- The script imports the matching PNG files as background assets inside data.win.

Expected border filenames include:

- RUINS_BORDER.png
- SONWDIN_BORDER.png
- WATERFALL_BORDER.png
- HOTELAND_BORDER.png
- DYNAMIC_BORDER_5.png
- DYNAMIC_BORDER_6.png
- 01.png
- 02.png

The script searches inside the folder you select, including subfolders, so the PNGs can stay inside folders like DYNAMIC and OTHER.

Note about asset rights:
If you share this mod publicly, make sure you are allowed to redistribute any border image assets included in your download package. The mod itself can run without included border images, and users can import their own local border PNGs if needed. 


HOW TO USE IN-GAME
------------------
Title screen:

- Open the normal UNDERTALE settings option.
- Settings+ should appear.
- Use the menu controls shown at the bottom of the screen.

In-game:

- Open the C Menu.
- Select SETTINGS to open Settings+.
- Select MAIN MENU if you want to return to the title/main menu.

General controls:

- Arrow keys: Move/select/change settings.
- Z: Confirm / OK.
- X: Back.

Controller input should follow UNDERTALE's normal control behavior as much as possible.


RECOMMENDED TEST CHECKLIST
--------------------------
After installing the mod, test these before calling the build done:

1. Open the title-screen Settings+ menu.
2. Move up and down through the Settings+ menu.
3. Change pages/tabs.
4. Toggle Fullscreen.
5. Change Window Size.
6. Change Border and confirm something visible changes.
7. Change Master Volume while music is playing.
8. Change Music Volume while music is playing.
9. Change SFX Volume and test a sound effect.
10. Open the in-game C Menu.
11. Open SETTINGS from the C Menu.
12. Return from Settings+ back to the game.
13. Open MAIN MENU from the C Menu.
14. Restart the game and confirm saved settings load again.


TROUBLESHOOTING
---------------
Problem: The script fails to import or compile.

- Make sure you are using a clean UNDERTALE PC data.win.
- Make sure the file is not already heavily patched by older test versions of the same mod.
- Restore your backup and run the script again.

Problem: Real borders do not show.

- Make sure UNDERTALE_Borders.zip was extracted before running the script.
- Make sure you selected the extracted folder, not the zip file.
- Make sure the expected PNG filenames are present.
- If real border import fails, the mod should still use fallback borders.

Problem: Audio settings do not seem to change existing music.

- Open Settings+ -> Audio and change Master or Music again.
- Leave and re-enter the room if a specific track was started before the settings were applied.
- If SFX works but music does not, restore a clean data.win and reinstall this v1 release script.

Problem: C Menu text overlaps other UI.

- The extra SETTINGS and MAIN MENU entries are intended to show only on the main C Menu page.
- If overlap appears after another mod is installed, there may be a patch conflict with the C Menu object/scripts.

Problem: The game acts weird after installing multiple versions of the mod.

- Do not stack multiple builds on the same data.win.
- Restore a clean backup and install only this release version.


UNINSTALL / RESTORE
-------------------
The easiest uninstall method is to restore your backed-up clean data.win.

This mod patches multiple GML scripts and objects, so manual uninstall is not recommended unless you know exactly which code was changed.


MODDING NOTES
-------------
This mod is made for UNDERTALE PC using UndertaleModTool.

For best results:

- Use a clean data.win.
- Keep a backup.
- Do not stack older builds of this same mod.
- Test before uploading or sharing a release.
- Keep custom border PNG filenames consistent if you want the script to auto-detect them.


CREDITS
-------
Mod concept / release direction:
sonic Fan Tech

Installer / GML patch package:
SFT UNDERTALE Settings+ Mod v1

Tool used:
UndertaleModTool

Game:
UNDERTALE by Toby Fox


END OF README
-------------
